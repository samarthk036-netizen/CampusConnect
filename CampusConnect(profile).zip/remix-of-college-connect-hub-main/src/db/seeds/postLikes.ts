import { db } from '@/db';
import { postLikes } from '@/db/schema';

async function main() {
    const samplePostLikes = [
        // Post 1: High engagement achievement post (150+ likes from 12-15 profiles)
        { postId: 1, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-15T10:30:00').toISOString() },
        { postId: 1, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-15T11:15:00').toISOString() },
        { postId: 1, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-15T12:45:00').toISOString() },
        { postId: 1, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-15T14:20:00').toISOString() },
        { postId: 1, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-15T16:30:00').toISOString() },
        { postId: 1, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-16T09:00:00').toISOString() },
        { postId: 1, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-16T10:30:00').toISOString() },
        { postId: 1, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-16T13:15:00').toISOString() },
        { postId: 1, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-16T15:45:00').toISOString() },
        { postId: 1, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-17T08:20:00').toISOString() },
        { postId: 1, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-17T11:00:00').toISOString() },
        { postId: 1, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-17T14:30:00').toISOString() },
        { postId: 1, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-18T09:15:00').toISOString() },
        { postId: 1, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-01-18T12:00:00').toISOString() },
        { postId: 1, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-18T16:45:00').toISOString() },

        // Post 2: Medium engagement technical post (70-150 likes from 8-12 CS/IT/EC students)
        { postId: 2, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-16T11:00:00').toISOString() },
        { postId: 2, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-16T12:30:00').toISOString() },
        { postId: 2, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-16T14:15:00').toISOString() },
        { postId: 2, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-16T16:45:00').toISOString() },
        { postId: 2, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-17T09:20:00').toISOString() },
        { postId: 2, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-17T11:00:00').toISOString() },
        { postId: 2, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-17T13:30:00').toISOString() },
        { postId: 2, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-17T15:15:00').toISOString() },
        { postId: 2, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-18T10:00:00').toISOString() },
        { postId: 2, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-18T14:30:00').toISOString() },

        // Post 3: Low engagement casual post (30-70 likes from 4-8 profiles)
        { postId: 3, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-17T12:00:00').toISOString() },
        { postId: 3, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-17T13:45:00').toISOString() },
        { postId: 3, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-17T15:30:00').toISOString() },
        { postId: 3, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-18T09:15:00').toISOString() },
        { postId: 3, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-18T11:00:00').toISOString() },
        { postId: 3, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-01-18T14:20:00').toISOString() },

        // Post 4: High engagement event announcement (150+ likes from 12-15 profiles)
        { postId: 4, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-18T10:00:00').toISOString() },
        { postId: 4, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-18T10:45:00').toISOString() },
        { postId: 4, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-18T11:30:00').toISOString() },
        { postId: 4, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-18T12:15:00').toISOString() },
        { postId: 4, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-18T13:00:00').toISOString() },
        { postId: 4, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-18T14:30:00').toISOString() },
        { postId: 4, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-18T15:45:00').toISOString() },
        { postId: 4, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-19T09:00:00').toISOString() },
        { postId: 4, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-19T10:30:00').toISOString() },
        { postId: 4, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-19T12:00:00').toISOString() },
        { postId: 4, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-19T13:15:00').toISOString() },
        { postId: 4, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-19T14:45:00').toISOString() },
        { postId: 4, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-19T16:00:00').toISOString() },
        { postId: 4, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-20T10:30:00').toISOString() },

        // Post 5: Medium engagement technical discussion (70-150 likes from CS/IT students)
        { postId: 5, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-19T11:00:00').toISOString() },
        { postId: 5, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-19T12:30:00').toISOString() },
        { postId: 5, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-19T14:00:00').toISOString() },
        { postId: 5, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-19T15:30:00').toISOString() },
        { postId: 5, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-20T09:15:00').toISOString() },
        { postId: 5, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-20T11:00:00').toISOString() },
        { postId: 5, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-20T13:30:00').toISOString() },
        { postId: 5, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-20T15:00:00').toISOString() },
        { postId: 5, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-21T10:20:00').toISOString() },

        // Post 6: Low engagement general post (30-70 likes from 4-8 profiles)
        { postId: 6, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-20T12:00:00').toISOString() },
        { postId: 6, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-20T13:30:00').toISOString() },
        { postId: 6, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-20T15:00:00').toISOString() },
        { postId: 6, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-21T09:30:00').toISOString() },
        { postId: 6, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-21T11:15:00').toISOString() },

        // Post 7: Faculty research post (70-150 likes from respectful students)
        { postId: 7, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-21T10:00:00').toISOString() },
        { postId: 7, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-21T11:00:00').toISOString() },
        { postId: 7, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-21T12:30:00').toISOString() },
        { postId: 7, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-21T14:00:00').toISOString() },
        { postId: 7, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-21T15:30:00').toISOString() },
        { postId: 7, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-22T09:00:00').toISOString() },
        { postId: 7, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-22T10:30:00').toISOString() },
        { postId: 7, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-22T12:00:00').toISOString() },
        { postId: 7, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-22T14:30:00').toISOString() },
        { postId: 7, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-23T10:00:00').toISOString() },

        // Post 8: High engagement placement success (150+ likes from 12-15 profiles)
        { postId: 8, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-22T11:00:00').toISOString() },
        { postId: 8, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-22T11:45:00').toISOString() },
        { postId: 8, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-22T12:30:00').toISOString() },
        { postId: 8, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-22T13:15:00').toISOString() },
        { postId: 8, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-22T14:00:00').toISOString() },
        { postId: 8, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-22T15:30:00').toISOString() },
        { postId: 8, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-23T09:00:00').toISOString() },
        { postId: 8, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-23T10:30:00').toISOString() },
        { postId: 8, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-23T12:00:00').toISOString() },
        { postId: 8, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-23T13:30:00').toISOString() },
        { postId: 8, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-23T15:00:00').toISOString() },
        { postId: 8, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-24T09:30:00').toISOString() },
        { postId: 8, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-24T11:00:00').toISOString() },
        { postId: 8, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-01-24T13:30:00').toISOString() },
        { postId: 8, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-24T15:00:00').toISOString() },

        // Post 9: Medium engagement project showcase (70-150 likes from technical students)
        { postId: 9, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-23T12:00:00').toISOString() },
        { postId: 9, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-23T13:30:00').toISOString() },
        { postId: 9, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-23T15:00:00').toISOString() },
        { postId: 9, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-24T09:15:00').toISOString() },
        { postId: 9, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-24T11:00:00').toISOString() },
        { postId: 9, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-24T13:30:00').toISOString() },
        { postId: 9, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-24T15:00:00').toISOString() },
        { postId: 9, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-25T10:00:00').toISOString() },
        { postId: 9, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-25T12:30:00').toISOString() },

        // Post 10: Low engagement casual campus life (30-70 likes from 4-8 profiles)
        { postId: 10, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-24T13:00:00').toISOString() },
        { postId: 10, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-24T14:30:00').toISOString() },
        { postId: 10, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-24T16:00:00').toISOString() },
        { postId: 10, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-25T09:30:00').toISOString() },
        { postId: 10, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-25T11:15:00').toISOString() },
        { postId: 10, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-25T14:00:00').toISOString() },

        // Post 11: High engagement sports tournament (150+ likes from 12-15 profiles)
        { postId: 11, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-25T11:00:00').toISOString() },
        { postId: 11, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-25T11:45:00').toISOString() },
        { postId: 11, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-25T12:30:00').toISOString() },
        { postId: 11, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-25T13:15:00').toISOString() },
        { postId: 11, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-25T14:00:00').toISOString() },
        { postId: 11, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-25T15:30:00').toISOString() },
        { postId: 11, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-26T09:00:00').toISOString() },
        { postId: 11, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-26T10:30:00').toISOString() },
        { postId: 11, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-26T12:00:00').toISOString() },
        { postId: 11, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-26T13:30:00').toISOString() },
        { postId: 11, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-26T15:00:00').toISOString() },
        { postId: 11, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-27T09:30:00').toISOString() },
        { postId: 11, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-27T11:00:00').toISOString() },
        { postId: 11, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-01-27T13:30:00').toISOString() },

        // Post 12: Medium engagement coding competition (70-150 likes from CS/IT students)
        { postId: 12, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-26T12:00:00').toISOString() },
        { postId: 12, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-26T13:30:00').toISOString() },
        { postId: 12, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-26T15:00:00').toISOString() },
        { postId: 12, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-27T09:15:00').toISOString() },
        { postId: 12, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-27T11:00:00').toISOString() },
        { postId: 12, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-27T13:30:00').toISOString() },
        { postId: 12, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-27T15:00:00').toISOString() },
        { postId: 12, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-28T10:00:00').toISOString() },
        { postId: 12, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-28T12:30:00').toISOString() },

        // Post 13: Low engagement study tips (30-70 likes from 4-8 profiles)
        { postId: 13, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-27T13:00:00').toISOString() },
        { postId: 13, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-27T14:30:00').toISOString() },
        { postId: 13, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-27T16:00:00').toISOString() },
        { postId: 13, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-28T09:30:00').toISOString() },
        { postId: 13, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-28T11:15:00').toISOString() },

        // Post 14: Faculty announcement (70-150 likes from respectful students)
        { postId: 14, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-01-28T10:00:00').toISOString() },
        { postId: 14, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-28T11:00:00').toISOString() },
        { postId: 14, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-28T12:30:00').toISOString() },
        { postId: 14, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-28T14:00:00').toISOString() },
        { postId: 14, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-28T15:30:00').toISOString() },
        { postId: 14, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-29T09:00:00').toISOString() },
        { postId: 14, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-29T10:30:00').toISOString() },
        { postId: 14, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-29T12:00:00').toISOString() },
        { postId: 14, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-29T14:30:00').toISOString() },

        // Post 15: High engagement hackathon win (150+ likes from 12-15 profiles)
        { postId: 15, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-01-29T11:00:00').toISOString() },
        { postId: 15, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-29T11:45:00').toISOString() },
        { postId: 15, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-29T12:30:00').toISOString() },
        { postId: 15, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-29T13:15:00').toISOString() },
        { postId: 15, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-29T14:00:00').toISOString() },
        { postId: 15, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-29T15:30:00').toISOString() },
        { postId: 15, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-01-30T09:00:00').toISOString() },
        { postId: 15, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-30T10:30:00').toISOString() },
        { postId: 15, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-30T12:00:00').toISOString() },
        { postId: 15, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-30T13:30:00').toISOString() },
        { postId: 15, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-01-30T15:00:00').toISOString() },
        { postId: 15, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-31T09:30:00').toISOString() },
        { postId: 15, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-01-31T11:00:00').toISOString() },
        { postId: 15, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-31T13:30:00').toISOString() },

        // Continue with remaining posts (16-55) following similar patterns
        // Post 16-20: Mix of medium engagement posts
        { postId: 16, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-01-30T12:00:00').toISOString() },
        { postId: 16, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-01-30T13:30:00').toISOString() },
        { postId: 16, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-01-30T15:00:00').toISOString() },
        { postId: 16, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-01-31T09:15:00').toISOString() },
        { postId: 16, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-01-31T11:00:00').toISOString() },
        { postId: 16, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-01-31T13:30:00').toISOString() },

        { postId: 17, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-01-31T11:00:00').toISOString() },
        { postId: 17, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-01-31T12:30:00').toISOString() },
        { postId: 17, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-01-31T14:00:00').toISOString() },
        { postId: 17, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-01-31T15:30:00').toISOString() },

        { postId: 18, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-01T10:00:00').toISOString() },
        { postId: 18, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-01T11:30:00').toISOString() },
        { postId: 18, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-01T13:00:00').toISOString() },
        { postId: 18, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-01T14:30:00').toISOString() },
        { postId: 18, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-01T16:00:00').toISOString() },

        { postId: 19, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-01T12:00:00').toISOString() },
        { postId: 19, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-01T13:30:00').toISOString() },
        { postId: 19, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-01T15:00:00').toISOString() },
        { postId: 19, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-02-02T10:00:00').toISOString() },

        { postId: 20, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-02T11:00:00').toISOString() },
        { postId: 20, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-02T12:30:00').toISOString() },
        { postId: 20, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-02T14:00:00').toISOString() },
        { postId: 20, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-02T15:30:00').toISOString() },
        { postId: 20, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-02-03T09:00:00').toISOString() },

        // Additional engagement patterns for posts 21-55
        { postId: 21, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-03T10:00:00').toISOString() },
        { postId: 21, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-03T11:30:00').toISOString() },
        { postId: 21, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-03T13:00:00').toISOString() },

        { postId: 22, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-03T12:00:00').toISOString() },
        { postId: 22, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-03T13:30:00').toISOString() },
        { postId: 22, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-03T15:00:00').toISOString() },
        { postId: 22, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-04T10:00:00').toISOString() },

        { postId: 23, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-04T11:00:00').toISOString() },
        { postId: 23, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-04T12:30:00').toISOString() },
        { postId: 23, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-04T14:00:00').toISOString() },
        { postId: 23, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-04T15:30:00').toISOString() },

        { postId: 24, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-04T13:00:00').toISOString() },
        { postId: 24, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-04T14:30:00').toISOString() },
        { postId: 24, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-04T16:00:00').toISOString() },

        { postId: 25, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-05T10:00:00').toISOString() },
        { postId: 25, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-05T11:30:00').toISOString() },
        { postId: 25, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-05T13:00:00').toISOString() },
        { postId: 25, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-05T14:30:00').toISOString() },

        { postId: 26, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-05T12:00:00').toISOString() },
        { postId: 26, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-05T13:30:00').toISOString() },
        { postId: 26, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-05T15:00:00').toISOString() },

        { postId: 27, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-06T10:00:00').toISOString() },
        { postId: 27, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-06T11:30:00').toISOString() },
        { postId: 27, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-06T13:00:00').toISOString() },
        { postId: 27, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-06T14:30:00').toISOString() },

        { postId: 28, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-06T12:00:00').toISOString() },
        { postId: 28, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-06T13:30:00').toISOString() },
        { postId: 28, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-06T15:00:00').toISOString() },

        { postId: 29, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-02-07T10:00:00').toISOString() },
        { postId: 29, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-07T11:30:00').toISOString() },
        { postId: 29, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-07T13:00:00').toISOString() },
        { postId: 29, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-07T14:30:00').toISOString() },

        { postId: 30, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-02-07T12:00:00').toISOString() },
        { postId: 30, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-07T13:30:00').toISOString() },
        { postId: 30, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-07T15:00:00').toISOString() },

        { postId: 31, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-02-08T10:00:00').toISOString() },
        { postId: 31, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-08T11:30:00').toISOString() },
        { postId: 31, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-08T13:00:00').toISOString() },
        { postId: 31, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-08T14:30:00').toISOString() },

        { postId: 32, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-08T12:00:00').toISOString() },
        { postId: 32, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-08T13:30:00').toISOString() },
        { postId: 32, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-08T15:00:00').toISOString() },

        { postId: 33, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-09T10:00:00').toISOString() },
        { postId: 33, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-09T11:30:00').toISOString() },
        { postId: 33, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-09T13:00:00').toISOString() },
        { postId: 33, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-09T14:30:00').toISOString() },

        { postId: 34, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-09T12:00:00').toISOString() },
        { postId: 34, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-09T13:30:00').toISOString() },
        { postId: 34, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-09T15:00:00').toISOString() },

        { postId: 35, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-10T10:00:00').toISOString() },
        { postId: 35, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-10T11:30:00').toISOString() },
        { postId: 35, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-10T13:00:00').toISOString() },
        { postId: 35, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-02-10T14:30:00').toISOString() },

        { postId: 36, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-10T12:00:00').toISOString() },
        { postId: 36, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-10T13:30:00').toISOString() },
        { postId: 36, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-10T15:00:00').toISOString() },

        { postId: 37, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-11T10:00:00').toISOString() },
        { postId: 37, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-11T11:30:00').toISOString() },
        { postId: 37, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-11T13:00:00').toISOString() },
        { postId: 37, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-11T14:30:00').toISOString() },

        { postId: 38, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-11T12:00:00').toISOString() },
        { postId: 38, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-11T13:30:00').toISOString() },
        { postId: 38, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-11T15:00:00').toISOString() },

        { postId: 39, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-12T10:00:00').toISOString() },
        { postId: 39, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-12T11:30:00').toISOString() },
        { postId: 39, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-12T13:00:00').toISOString() },
        { postId: 39, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-12T14:30:00').toISOString() },

        { postId: 40, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-12T12:00:00').toISOString() },
        { postId: 40, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-12T13:30:00').toISOString() },
        { postId: 40, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-12T15:00:00').toISOString() },

        { postId: 41, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-13T10:00:00').toISOString() },
        { postId: 41, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-13T11:30:00').toISOString() },
        { postId: 41, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-13T13:00:00').toISOString() },
        { postId: 41, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-13T14:30:00').toISOString() },

        { postId: 42, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-13T12:00:00').toISOString() },
        { postId: 42, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-13T13:30:00').toISOString() },
        { postId: 42, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-13T15:00:00').toISOString() },

        { postId: 43, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-14T10:00:00').toISOString() },
        { postId: 43, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-14T11:30:00').toISOString() },
        { postId: 43, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-14T13:00:00').toISOString() },
        { postId: 43, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-14T14:30:00').toISOString() },

        { postId: 44, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-02-14T12:00:00').toISOString() },
        { postId: 44, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-14T13:30:00').toISOString() },
        { postId: 44, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-14T15:00:00').toISOString() },

        { postId: 45, userId: 'user_14h7x0g5r1m2l6o4a0z9d8j1e7', createdAt: new Date('2024-02-15T10:00:00').toISOString() },
        { postId: 45, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-15T11:30:00').toISOString() },
        { postId: 45, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-15T13:00:00').toISOString() },
        { postId: 45, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-15T14:30:00').toISOString() },

        { postId: 46, userId: 'user_15h8y1h6s2n3m7p5b1a0e9k2f8', createdAt: new Date('2024-02-15T12:00:00').toISOString() },
        { postId: 46, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-15T13:30:00').toISOString() },
        { postId: 46, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-15T15:00:00').toISOString() },

        { postId: 47, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-16T10:00:00').toISOString() },
        { postId: 47, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-16T11:30:00').toISOString() },
        { postId: 47, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-16T13:00:00').toISOString() },
        { postId: 47, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-16T14:30:00').toISOString() },

        { postId: 48, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-16T12:00:00').toISOString() },
        { postId: 48, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-16T13:30:00').toISOString() },
        { postId: 48, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-16T15:00:00').toISOString() },

        { postId: 49, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-17T10:00:00').toISOString() },
        { postId: 49, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-17T11:30:00').toISOString() },
        { postId: 49, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-17T13:00:00').toISOString() },
        { postId: 49, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-17T14:30:00').toISOString() },

        { postId: 50, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-17T12:00:00').toISOString() },
        { postId: 50, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-17T13:30:00').toISOString() },
        { postId: 50, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-17T15:00:00').toISOString() },

        { postId: 51, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-18T10:00:00').toISOString() },
        { postId: 51, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-18T11:30:00').toISOString() },
        { postId: 51, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-18T13:00:00').toISOString() },
        { postId: 51, userId: 'user_13h6w9f4q0l1k5n3z9y8c7i0d6', createdAt: new Date('2024-02-18T14:30:00').toISOString() },

        { postId: 52, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-18T12:00:00').toISOString() },
        { postId: 52, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-18T13:30:00').toISOString() },
        { postId: 52, userId: 'user_10h3t6c1n7i8h2k0w6v5z4f7a3', createdAt: new Date('2024-02-18T15:00:00').toISOString() },

        { postId: 53, userId: 'user_07h0q3z8k4f5e9h7t3s2w1c4x0', createdAt: new Date('2024-02-19T10:00:00').toISOString() },
        { postId: 53, userId: 'user_01h4kxt2e8z9y3b1n7m6q5w8r4', createdAt: new Date('2024-02-19T11:30:00').toISOString() },
        { postId: 53, userId: 'user_04h7n0w5h1c2b6e4q0p9t8z1u7', createdAt: new Date('2024-02-19T13:00:00').toISOString() },
        { postId: 53, userId: 'user_11h4u7d2o8j9i3l1x7w6a5g8b4', createdAt: new Date('2024-02-19T14:30:00').toISOString() },

        { postId: 54, userId: 'user_08h1r4a9l5g6f0i8u4t3x2d5y1', createdAt: new Date('2024-02-19T12:00:00').toISOString() },
        { postId: 54, userId: 'user_02h5lyu3f9a0z4c2o8n7r6x9s5', createdAt: new Date('2024-02-19T13:30:00').toISOString() },
        { postId: 54, userId: 'user_05h8o1x6i2d3c7f5r1q0u9a2v8', createdAt: new Date('2024-02-19T15:00:00').toISOString() },

        { postId: 55, userId: 'user_09h2s5b0m6h7g1j9v5u4y3e6z2', createdAt: new Date('2024-02-20T10:00:00').toISOString() },
        { postId: 55, userId: 'user_03h6mzv4g0b1a5d3p9o8s7y0t6', createdAt: new Date('2024-02-20T11:30:00').toISOString() },
        { postId: 55, userId: 'user_06h9p2y7j3e4d8g6s2r1v0b3w9', createdAt: new Date('2024-02-20T13:00:00').toISOString() },
        { postId: 55, userId: 'user_12h5v8e3p9k0j4m2y8x7b6h9c5', createdAt: new Date('2024-02-20T14:30:00').toISOString() },
    ];

    await db.insert(postLikes).values(samplePostLikes);
    
    console.log('✅ Post likes seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});