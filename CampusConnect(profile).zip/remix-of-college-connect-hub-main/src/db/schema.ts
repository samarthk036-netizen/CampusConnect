import { sqliteTable, integer, text } from 'drizzle-orm/sqlite-core';

// Profiles table - Extended user information
export const profiles = sqliteTable('profiles', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: text('user_id').notNull().unique(), // for auth integration
  fullName: text('full_name').notNull(),
  email: text('email').notNull().unique(),
  usnOrFacultyId: text('usn_or_faculty_id').notNull().unique(),
  userType: text('user_type').notNull(), // 'student' or 'faculty'
  department: text('department').notNull(),
  yearOrDesignation: text('year_or_designation').notNull(),
  bio: text('bio'),
  profileImageUrl: text('profile_image_url'),
  coverImageUrl: text('cover_image_url'),
  location: text('location'),
  website: text('website'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
});

// Achievements table - LinkedIn-style achievements
export const achievements = sqliteTable('achievements', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  title: text('title').notNull(),
  description: text('description'),
  achievementType: text('achievement_type').notNull(), // 'academic', 'sports', 'cultural', 'technical', 'leadership', 'other'
  dateAchieved: text('date_achieved').notNull(), // ISO date string
  imageUrl: text('image_url'),
  createdAt: text('created_at').notNull(),
});

// Posts table - Instagram-style feed posts
export const posts = sqliteTable('posts', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  content: text('content').notNull(),
  imageUrl: text('image_url'),
  likesCount: integer('likes_count').notNull().default(0),
  commentsCount: integer('comments_count').notNull().default(0),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
});

// Post likes table - Track who liked which post
export const postLikes = sqliteTable('post_likes', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  postId: integer('post_id').notNull().references(() => posts.id),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  createdAt: text('created_at').notNull(),
});

// Comments table - Comments on posts
export const comments = sqliteTable('comments', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  postId: integer('post_id').notNull().references(() => posts.id),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  content: text('content').notNull(),
  createdAt: text('created_at').notNull(),
});

// Communities table - WhatsApp-style sub-communities
export const communities = sqliteTable('communities', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  description: text('description'),
  category: text('category').notNull(), // 'study', 'hobby', 'club', 'carpool', 'sports', 'other'
  avatarUrl: text('avatar_url'),
  createdBy: integer('created_by').notNull().references(() => profiles.id),
  isPrivate: integer('is_private', { mode: 'boolean' }).notNull().default(false),
  memberCount: integer('member_count').notNull().default(1),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
});

// Community members table - Track membership
export const communityMembers = sqliteTable('community_members', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  communityId: integer('community_id').notNull().references(() => communities.id),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  role: text('role').notNull().default('member'), // 'admin', 'moderator', 'member'
  joinedAt: text('joined_at').notNull(),
});

// Community posts table - Posts within communities
export const communityPosts = sqliteTable('community_posts', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  communityId: integer('community_id').notNull().references(() => communities.id),
  profileId: integer('profile_id').notNull().references(() => profiles.id),
  content: text('content').notNull(),
  imageUrl: text('image_url'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
});