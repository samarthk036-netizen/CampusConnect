import { GoogleGenerativeAI } from '@google/generative-ai'

const apiKey = process.env.GEMINI_API_KEY || ''

let genAI: GoogleGenerativeAI | null = null

if (apiKey) {
  genAI = new GoogleGenerativeAI(apiKey)
}

export async function moderateContent(content: string): Promise<{
  isAppropriate: boolean
  reason?: string
  suggestions?: string[]
}> {
  if (!genAI) {
    // If API key is not configured, allow all content
    return { isAppropriate: true }
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' })

    const prompt = `You are a content moderator for a college community platform. 
Analyze the following content and determine if it's appropriate for a college environment.
Check for: hate speech, harassment, explicit content, spam, or inappropriate language.

Content: "${content}"

Respond in JSON format with:
{
  "isAppropriate": true/false,
  "reason": "brief explanation if inappropriate",
  "suggestions": ["suggestion1", "suggestion2"] (if content can be improved)
}

Keep it concise and helpful.`

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()
    
    // Parse JSON response
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }

    return { isAppropriate: true }
  } catch (error) {
    console.error('Gemini moderation error:', error)
    // On error, allow content to be posted
    return { isAppropriate: true }
  }
}

export async function generatePostSuggestions(topic: string): Promise<string[]> {
  if (!genAI) {
    return []
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' })

    const prompt = `Generate 3 engaging post ideas for a college community platform about: "${topic}"
Keep them appropriate, friendly, and relevant to college life.
Return only the ideas as a JSON array of strings.

Example format:
["idea 1", "idea 2", "idea 3"]`

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()
    
    // Parse JSON response
    const jsonMatch = text.match(/\[[\s\S]*\]/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }

    return []
  } catch (error) {
    console.error('Gemini suggestions error:', error)
    return []
  }
}

export async function enhanceAchievementDescription(
  title: string,
  description: string,
  type: string
): Promise<string> {
  if (!genAI) {
    return description
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' })

    const prompt = `Enhance this ${type} description for a LinkedIn-style achievement section.
Make it professional, concise, and impactful. Keep it under 150 words.

Title: ${title}
Current Description: ${description}

Return only the enhanced description without any additional formatting or labels.`

    const result = await model.generateContent(prompt)
    const response = await result.response
    return response.text().trim()
  } catch (error) {
    console.error('Gemini enhancement error:', error)
    return description
  }
}

export async function generateCommunityDescription(
  name: string,
  category: string
): Promise<string> {
  if (!genAI) {
    return ''
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' })

    const prompt = `Generate a brief, engaging description for a college community group.

Name: ${name}
Category: ${category}

Keep it friendly, concise (under 100 words), and appealing to college students.
Return only the description without any additional formatting.`

    const result = await model.generateContent(prompt)
    const response = await result.response
    return response.text().trim()
  } catch (error) {
    console.error('Gemini description error:', error)
    return ''
  }
}
