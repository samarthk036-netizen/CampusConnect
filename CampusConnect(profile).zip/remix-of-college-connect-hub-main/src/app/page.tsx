import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  GraduationCap, 
  Trophy, 
  Users, 
  MessageSquare,
  ArrowRight
} from "lucide-react";
import { db } from "@/lib/db";
import { profiles } from "@/db/schema";
import { desc } from "drizzle-orm";

export const metadata = {
  title: "Campus Connect - College Community Platform",
  description: "A vibrant community platform exclusively for college students and faculty. Share achievements, connect with peers, and celebrate success together.",
};

async function getFeaturedProfiles() {
  try {
    // Fetch 3 diverse profiles (mix of students and faculty)
    const allProfiles = await db
      .select()
      .from(profiles)
      .orderBy(desc(profiles.createdAt))
      .limit(10);
    
    // Get a mix: 2 students and 1 faculty if possible
    const students = allProfiles.filter(p => p.userType === 'student').slice(0, 2);
    const faculty = allProfiles.filter(p => p.userType === 'faculty').slice(0, 1);
    
    return [...students, ...faculty].slice(0, 3);
  } catch (error) {
    console.error("Error fetching profiles:", error);
    // Fallback to demo data if database fails
    return [
      { id: 1, fullName: "Aarav Sharma", userType: "student", department: "Computer Science" },
      { id: 4, fullName: "Ananya Reddy", userType: "student", department: "Information Technology" },
      { id: 11, fullName: "Dr. Rajesh Kumar", userType: "faculty", department: "Computer Science" },
    ];
  }
}

export default async function Home() {
  const demoProfiles = await getFeaturedProfiles();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-purple-900 dark:to-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            College Community Platform
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            Connect. Achieve. Inspire.
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            A vibrant community platform exclusively for college students and faculty. 
            Share achievements, connect with peers, and celebrate success together.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/create-profile">
                Create Your Profile
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="#features">
                Learn More
              </Link>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div id="features" className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="font-semibold mb-2">Student Profiles</h3>
            <p className="text-sm text-muted-foreground">
              Showcase your academic journey and skills
            </p>
          </Card>

          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="font-semibold mb-2">Achievements</h3>
            <p className="text-sm text-muted-foreground">
              Celebrate your wins and milestones
            </p>
          </Card>

          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-pink-100 dark:bg-pink-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-6 h-6 text-pink-600 dark:text-pink-400" />
            </div>
            <h3 className="font-semibold mb-2">Community</h3>
            <p className="text-sm text-muted-foreground">
              Connect with students and faculty
            </p>
          </Card>

          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="font-semibold mb-2">Social Feed</h3>
            <p className="text-sm text-muted-foreground">
              Share updates and stay connected
            </p>
          </Card>
        </div>

        {/* Demo Profiles Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Featured Profiles</h2>
          <p className="text-muted-foreground mb-8">
            Discover amazing students and faculty in our community
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {demoProfiles.map((profile) => (
            <Link key={profile.id} href={`/profile/${profile.id}`}>
              <Card className="p-6 hover:shadow-lg transition-all cursor-pointer hover:-translate-y-1 h-full">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                  {profile.fullName.charAt(0)}
                </div>
                <h3 className="font-semibold text-center mb-2">{profile.fullName}</h3>
                <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-4">
                  <Badge variant="secondary" className="capitalize">
                    {profile.userType}
                  </Badge>
                  <span>•</span>
                  <span className="text-center">{profile.department}</span>
                </div>
                <Button className="w-full" variant="outline">
                  View Profile
                </Button>
              </Card>
            </Link>
          ))}
        </div>

        {/* CTA Section */}
        <Card className="p-8 text-center bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg mb-6 opacity-90">
            Join thousands of students and faculty in our vibrant community
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/create-profile">
              Create Your Profile
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        </Card>
      </div>
    </div>
  );
}