"use client"

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { ProfileHeader } from "@/components/profile/ProfileHeader";
import { ProfileTabs } from "@/components/profile/ProfileTabs";
import { EditProfileModal } from "@/components/profile/EditProfileModal";
import { AddAchievementModal } from "@/components/profile/AddAchievementModal";
import { Loader2 } from "lucide-react";

interface ProfileData {
  profile: any;
  achievements: any[];
  posts: any[];
}

export default function ProfilePage() {
  const params = useParams();
  const profileId = params.id as string;

  const [data, setData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddAchievementModalOpen, setIsAddAchievementModalOpen] = useState(false);
  
  // For demo purposes, assume this is the current user's profile
  const isOwnProfile = true;

  useEffect(() => {
    fetchProfileData();
  }, [profileId]);

  const fetchProfileData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/profiles/${profileId}`);
      if (!response.ok) throw new Error("Failed to fetch profile");
      
      const profileData = await response.json();
      setData(profileData);
    } catch (error) {
      console.error("Error fetching profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (formData: any) => {
    try {
      const response = await fetch(`/api/profiles/${profileId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error("Failed to update profile");

      // Refresh profile data
      await fetchProfileData();
    } catch (error) {
      console.error("Error updating profile:", error);
      throw error;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Profile Not Found</h2>
          <p className="text-muted-foreground">
            The profile you're looking for doesn't exist.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
        {/* Profile Header */}
        <ProfileHeader
          profile={data.profile}
          isOwnProfile={isOwnProfile}
          onEdit={() => setIsEditModalOpen(true)}
        />

        {/* Tabbed Interface */}
        <ProfileTabs
          profile={data.profile}
          achievements={data.achievements}
          isOwnProfile={isOwnProfile}
          onAddAchievement={() => setIsAddAchievementModalOpen(true)}
        />
      </div>

      {/* Modals */}
      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        profile={data.profile}
        onSave={handleSaveProfile}
      />

      <AddAchievementModal
        isOpen={isAddAchievementModalOpen}
        onClose={() => setIsAddAchievementModalOpen(false)}
        profileId={parseInt(profileId)}
        onSuccess={fetchProfileData}
      />
    </div>
  );
}