"use client"

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useAuth } from '@/hooks/useAuth'
import { Users, Send, ArrowLeft, Loader2, UserPlus, UserMinus } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface Community {
  id: number
  name: string
  description: string | null
  category: string
  memberCount: number
  isPrivate: boolean
  isMember?: boolean
}

interface CommunityPost {
  id: number
  communityId: number
  userId: string
  content: string
  imageUrl: string | null
  createdAt: string
  userFullName?: string
  userAvatarUrl?: string | null
}

export default function CommunityDetailPage() {
  const { user, loading: authLoading } = useAuth()
  const params = useParams()
  const router = useRouter()
  const communityId = params.id as string

  const [community, setCommunity] = useState<Community | null>(null)
  const [posts, setPosts] = useState<CommunityPost[]>([])
  const [loading, setLoading] = useState(true)
  const [posting, setPosting] = useState(false)
  const [joining, setJoining] = useState(false)
  const [newPost, setNewPost] = useState('')

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login')
    } else if (user && communityId) {
      fetchCommunityDetails()
      fetchPosts()
    }
  }, [user, authLoading, communityId])

  const fetchCommunityDetails = async () => {
    try {
      const response = await fetch(`/api/communities/${communityId}?userId=${user?.id}`)
      if (response.ok) {
        const data = await response.json()
        setCommunity(data)
      }
    } catch (error) {
      console.error('Error fetching community:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPosts = async () => {
    try {
      const response = await fetch(`/api/communities/${communityId}/posts`)
      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    }
  }

  const handleJoinToggle = async () => {
    setJoining(true)
    try {
      const endpoint = community?.isMember ? '/api/communities/leave' : '/api/communities/join'
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          communityId: parseInt(communityId),
          userId: user?.id,
        }),
      })

      if (response.ok) {
        fetchCommunityDetails()
        if (!community?.isMember) {
          fetchPosts()
        }
      }
    } catch (error) {
      console.error('Error toggling membership:', error)
    } finally {
      setJoining(false)
    }
  }

  const handleCreatePost = async () => {
    if (!newPost.trim()) return

    setPosting(true)
    try {
      const response = await fetch(`/api/communities/${communityId}/posts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          content: newPost,
        }),
      })

      if (response.ok) {
        setNewPost('')
        fetchPosts()
      }
    } catch (error) {
      console.error('Error creating post:', error)
    } finally {
      setPosting(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-muted/30">
        <div className="max-w-4xl mx-auto p-4 space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    )
  }

  if (!community) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Community not found</p>
            <Button className="mt-4" onClick={() => router.push('/communities')}>
              Back to Communities
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <Button
              variant="ghost"
              size="sm"
              className="w-fit mb-4"
              onClick={() => router.push('/communities')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Communities
            </Button>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="text-xl">
                    {community.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-2xl">{community.name}</CardTitle>
                  <div className="flex items-center gap-3 mt-2">
                    <Badge variant="outline" className="capitalize">{community.category}</Badge>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span>{community.memberCount} members</span>
                    </div>
                  </div>
                </div>
              </div>
              <Button
                onClick={handleJoinToggle}
                disabled={joining}
                variant={community.isMember ? "outline" : "default"}
                className="gap-2"
              >
                {joining ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {community.isMember ? 'Leaving...' : 'Joining...'}
                  </>
                ) : (
                  <>
                    {community.isMember ? (
                      <>
                        <UserMinus className="h-4 w-4" />
                        Leave
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        Join
                      </>
                    )}
                  </>
                )}
              </Button>
            </div>
            {community.description && (
              <CardDescription className="mt-4">{community.description}</CardDescription>
            )}
          </CardHeader>
        </Card>

        {/* Posts Section - Only for members */}
        {community.isMember ? (
          <>
            {/* Create Post */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Share with the community</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="What's on your mind?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  rows={3}
                />
                <Button
                  onClick={handleCreatePost}
                  disabled={posting || !newPost.trim()}
                  className="gap-2"
                >
                  {posting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Post
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Posts Feed */}
            {posts.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No posts yet. Start the conversation!
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {posts.map((post) => (
                  <Card key={post.id}>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={post.userAvatarUrl || undefined} />
                          <AvatarFallback>
                            {post.userFullName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{post.userFullName || 'Unknown User'}</p>
                          <p className="text-sm text-muted-foreground">
                            {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="whitespace-pre-wrap">{post.content}</p>
                      {post.imageUrl && (
                        <img
                          src={post.imageUrl}
                          alt="Post image"
                          className="mt-4 w-full rounded-lg object-cover max-h-96"
                        />
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              Join this community to see posts and participate in discussions
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
