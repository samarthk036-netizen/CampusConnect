import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, context } = body;

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: 'Gemini API key not configured' },
        { status: 500 }
      );
    }

    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    let prompt = '';

    if (type === 'post') {
      prompt = `As a college community app assistant, suggest 3 engaging post ideas for a ${context.userType} in ${context.department}. 
      Keep suggestions professional, relevant to college life, and inspiring. Return as JSON array with format: 
      [{"title": "Post Title", "content": "Post content"}]`;
    } else if (type === 'achievement') {
      prompt = `As a college community app assistant, suggest how to write an impressive achievement description for: "${context.title}".
      The achievement type is: ${context.achievementType}.
      Provide a concise, impactful description (2-3 sentences) that highlights skills, impact, and results.`;
    } else if (type === 'bio') {
      prompt = `As a college community app assistant, suggest a professional bio for a ${context.userType} in ${context.department}.
      Include their interests in: ${context.interests || 'technology and innovation'}.
      Keep it concise (2-3 sentences), professional, and authentic.`;
    }

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    return NextResponse.json({ suggestion: text });
  } catch (error) {
    console.error('Error generating AI suggestion:', error);
    return NextResponse.json(
      { error: 'Failed to generate suggestion' },
      { status: 500 }
    );
  }
}
