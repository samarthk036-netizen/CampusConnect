import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { posts } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { profileId, content, imageUrl } = body

    if (!profileId || !content) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const now = new Date().toISOString()

    const result = await db.insert(posts).values({
      profileId,
      content,
      imageUrl: imageUrl || null,
      likesCount: 0,
      commentsCount: 0,
      createdAt: now,
      updatedAt: now,
    }).returning()

    return NextResponse.json(result[0])
  } catch (error: any) {
    console.error('Post creation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create post' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const profileId = searchParams.get('profileId')

    if (profileId) {
      const userPosts = await db
        .select()
        .from(posts)
        .where(eq(posts.profileId, parseInt(profileId)))
        .orderBy(desc(posts.createdAt))

      return NextResponse.json(userPosts)
    }

    const allPosts = await db
      .select()
      .from(posts)
      .orderBy(desc(posts.createdAt))

    return NextResponse.json(allPosts)
  } catch (error: any) {
    console.error('Post fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch posts' },
      { status: 500 }
    )
  }
}