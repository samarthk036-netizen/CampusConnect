import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { posts, postLikes } from '@/db/schema'
import { eq, and } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { postId, userId } = body

    // Check if already liked
    const existingLike = await db
      .select()
      .from(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)))
      .limit(1)

    if (existingLike.length > 0) {
      // Unlike - remove like and decrement count
      await db
        .delete(postLikes)
        .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)))

      await db
        .update(posts)
        .set({ likesCount: existingLike[0].id }) // This is a workaround, we'll use SQL
        .where(eq(posts.id, postId))

      // Decrement likes count
      const post = await db.select().from(posts).where(eq(posts.id, postId)).limit(1)
      if (post.length > 0) {
        await db
          .update(posts)
          .set({ likesCount: Math.max(0, post[0].likesCount - 1) })
          .where(eq(posts.id, postId))
      }

      return NextResponse.json({ liked: false })
    } else {
      // Like - add like and increment count
      const now = new Date().toISOString()
      
      await db.insert(postLikes).values({
        postId,
        userId,
        createdAt: now,
      })

      // Increment likes count
      const post = await db.select().from(posts).where(eq(posts.id, postId)).limit(1)
      if (post.length > 0) {
        await db
          .update(posts)
          .set({ likesCount: post[0].likesCount + 1 })
          .where(eq(posts.id, postId))
      }

      return NextResponse.json({ liked: true })
    }
  } catch (error: any) {
    console.error('Like toggle error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to toggle like' },
      { status: 500 }
    )
  }
}
