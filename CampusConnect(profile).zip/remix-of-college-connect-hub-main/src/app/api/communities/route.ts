import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communities, communityMembers } from '@/db/schema'
import { desc } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, category, isPrivate, createdBy } = body

    const now = new Date().toISOString()

    const result = await db.insert(communities).values({
      name,
      description: description || null,
      category,
      avatarUrl: null,
      createdBy,
      isPrivate: isPrivate || false,
      memberCount: 1,
      createdAt: now,
      updatedAt: now,
    }).returning()

    // Add creator as admin member
    await db.insert(communityMembers).values({
      communityId: result[0].id,
      userId: createdBy,
      role: 'admin',
      joinedAt: now,
    })

    return NextResponse.json(result[0])
  } catch (error: any) {
    console.error('Community creation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create community' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const allCommunities = await db
      .select()
      .from(communities)
      .orderBy(desc(communities.createdAt))

    return NextResponse.json(allCommunities)
  } catch (error: any) {
    console.error('Communities fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch communities' },
      { status: 500 }
    )
  }
}
