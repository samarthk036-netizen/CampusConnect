import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communities, communityMembers } from '@/db/schema'
import { eq, and } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { communityId, userId } = body

    // Check if already a member
    const existingMember = await db
      .select()
      .from(communityMembers)
      .where(and(eq(communityMembers.communityId, communityId), eq(communityMembers.userId, userId)))
      .limit(1)

    if (existingMember.length > 0) {
      return NextResponse.json(
        { error: 'Already a member' },
        { status: 400 }
      )
    }

    const now = new Date().toISOString()

    // Add member
    await db.insert(communityMembers).values({
      communityId,
      userId,
      role: 'member',
      joinedAt: now,
    })

    // Increment member count
    const community = await db.select().from(communities).where(eq(communities.id, communityId)).limit(1)
    if (community.length > 0) {
      await db
        .update(communities)
        .set({ 
          memberCount: community[0].memberCount + 1,
          updatedAt: now
        })
        .where(eq(communities.id, communityId))
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Join community error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to join community' },
      { status: 500 }
    )
  }
}
