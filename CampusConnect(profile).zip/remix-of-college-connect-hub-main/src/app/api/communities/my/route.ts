import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communities, communityMembers } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    // Get communities where user is a member
    const userCommunities = await db
      .select({
        id: communities.id,
        name: communities.name,
        description: communities.description,
        category: communities.category,
        avatarUrl: communities.avatarUrl,
        createdBy: communities.createdBy,
        isPrivate: communities.isPrivate,
        memberCount: communities.memberCount,
        createdAt: communities.createdAt,
      })
      .from(communityMembers)
      .innerJoin(communities, eq(communityMembers.communityId, communities.id))
      .where(eq(communityMembers.userId, userId))
      .orderBy(desc(communities.createdAt))

    return NextResponse.json(userCommunities)
  } catch (error: any) {
    console.error('My communities fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch communities' },
      { status: 500 }
    )
  }
}
