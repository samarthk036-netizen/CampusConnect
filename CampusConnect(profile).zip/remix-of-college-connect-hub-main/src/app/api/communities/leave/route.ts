import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communities, communityMembers } from '@/db/schema'
import { eq, and } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { communityId, userId } = body

    // Delete membership
    await db
      .delete(communityMembers)
      .where(and(eq(communityMembers.communityId, communityId), eq(communityMembers.userId, userId)))

    // Decrement member count
    const community = await db.select().from(communities).where(eq(communities.id, communityId)).limit(1)
    if (community.length > 0) {
      const now = new Date().toISOString()
      await db
        .update(communities)
        .set({ 
          memberCount: Math.max(0, community[0].memberCount - 1),
          updatedAt: now
        })
        .where(eq(communities.id, communityId))
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Leave community error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to leave community' },
      { status: 500 }
    )
  }
}
