import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communityPosts, profiles } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { userId, content, imageUrl } = body
    const communityId = parseInt(params.id)

    const now = new Date().toISOString()

    const result = await db.insert(communityPosts).values({
      communityId,
      userId,
      content,
      imageUrl: imageUrl || null,
      createdAt: now,
      updatedAt: now,
    }).returning()

    return NextResponse.json(result[0])
  } catch (error: any) {
    console.error('Community post creation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create post' },
      { status: 500 }
    )
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const communityId = parseInt(params.id)

    const posts = await db
      .select({
        id: communityPosts.id,
        communityId: communityPosts.communityId,
        userId: communityPosts.userId,
        content: communityPosts.content,
        imageUrl: communityPosts.imageUrl,
        createdAt: communityPosts.createdAt,
        userFullName: profiles.fullName,
        userAvatarUrl: profiles.avatarUrl,
      })
      .from(communityPosts)
      .leftJoin(profiles, eq(communityPosts.userId, profiles.id))
      .where(eq(communityPosts.communityId, communityId))
      .orderBy(desc(communityPosts.createdAt))

    return NextResponse.json(posts)
  } catch (error: any) {
    console.error('Community posts fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch posts' },
      { status: 500 }
    )
  }
}
