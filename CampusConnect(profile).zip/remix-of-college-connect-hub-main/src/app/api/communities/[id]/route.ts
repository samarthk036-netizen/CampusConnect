import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { communities, communityMembers } from '@/db/schema'
import { eq, and } from 'drizzle-orm'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const communityId = parseInt(params.id)

    const community = await db
      .select()
      .from(communities)
      .where(eq(communities.id, communityId))
      .limit(1)

    if (community.length === 0) {
      return NextResponse.json(
        { error: 'Community not found' },
        { status: 404 }
      )
    }

    // Check if user is a member
    if (userId) {
      const membership = await db
        .select()
        .from(communityMembers)
        .where(and(eq(communityMembers.communityId, communityId), eq(communityMembers.userId, userId)))
        .limit(1)

      return NextResponse.json({
        ...community[0],
        isMember: membership.length > 0
      })
    }

    return NextResponse.json(community[0])
  } catch (error: any) {
    console.error('Community fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch community' },
      { status: 500 }
    )
  }
}
