import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { profiles } from '@/db/schema'
import { eq } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, fullName, email, usnOrFacultyId, userType, department, yearOrDesignation, bio, location, website } = body

    // Check if USN/Faculty ID already exists
    const existingProfile = await db.select().from(profiles).where(eq(profiles.usnOrFacultyId, usnOrFacultyId)).limit(1)
    
    if (existingProfile.length > 0) {
      return NextResponse.json(
        { error: 'USN/Faculty ID already registered' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingEmail = await db.select().from(profiles).where(eq(profiles.email, email)).limit(1)
    
    if (existingEmail.length > 0) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 400 }
      )
    }

    const now = new Date().toISOString()

    const result = await db.insert(profiles).values({
      userId,
      fullName,
      email,
      usnOrFacultyId,
      userType,
      department,
      yearOrDesignation,
      bio: bio || null,
      profileImageUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
      coverImageUrl: null,
      location: location || null,
      website: website || null,
      createdAt: now,
      updatedAt: now,
    }).returning()

    return NextResponse.json({ success: true, id: result[0].id })
  } catch (error: any) {
    console.error('Profile creation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create profile' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (userId) {
      const profile = await db.select().from(profiles).where(eq(profiles.id, userId)).limit(1)
      return NextResponse.json(profile[0] || null)
    }

    const allProfiles = await db.select().from(profiles)
    return NextResponse.json(allProfiles)
  } catch (error: any) {
    console.error('Profile fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch profiles' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, ...updates } = body

    const now = new Date().toISOString()

    await db.update(profiles)
      .set({ ...updates, updatedAt: now })
      .where(eq(profiles.id, id))

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Profile update error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to update profile' },
      { status: 500 }
    )
  }
}