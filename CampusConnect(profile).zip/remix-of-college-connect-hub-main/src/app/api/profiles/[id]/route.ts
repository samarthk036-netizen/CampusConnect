import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { profiles, achievements, posts } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const profileId = parseInt(id);

    // Fetch profile
    const profile = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, profileId))
      .limit(1);

    if (!profile.length) {
      return NextResponse.json(
        { error: 'Profile not found' },
        { status: 404 }
      );
    }

    // Fetch achievements
    const userAchievements = await db
      .select()
      .from(achievements)
      .where(eq(achievements.profileId, profileId))
      .orderBy(desc(achievements.dateAchieved));

    // Fetch posts
    const userPosts = await db
      .select()
      .from(posts)
      .where(eq(posts.profileId, profileId))
      .orderBy(desc(posts.createdAt));

    return NextResponse.json({
      profile: profile[0],
      achievements: userAchievements,
      posts: userPosts,
    });
  } catch (error) {
    console.error('Error fetching profile:', error);
    return NextResponse.json(
      { error: 'Failed to fetch profile' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const profileId = parseInt(id);
    const body = await request.json();

    const updatedProfile = await db
      .update(profiles)
      .set({
        ...body,
        updatedAt: new Date().toISOString(),
      })
      .where(eq(profiles.id, profileId))
      .returning();

    if (!updatedProfile.length) {
      return NextResponse.json(
        { error: 'Profile not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(updatedProfile[0]);
  } catch (error) {
    console.error('Error updating profile:', error);
    return NextResponse.json(
      { error: 'Failed to update profile' },
      { status: 500 }
    );
  }
}