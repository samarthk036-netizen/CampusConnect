import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { achievements } from '@/db/schema'
import { eq, desc } from 'drizzle-orm'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { profileId, title, description, achievementType, dateAchieved, imageUrl } = body

    if (!profileId || !title || !achievementType || !dateAchieved) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const now = new Date().toISOString()

    const result = await db.insert(achievements).values({
      profileId,
      title,
      description: description || null,
      achievementType,
      dateAchieved,
      imageUrl: imageUrl || null,
      createdAt: now,
    }).returning()

    return NextResponse.json(result[0])
  } catch (error: any) {
    console.error('Achievement creation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create achievement' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const profileId = searchParams.get('profileId')

    if (profileId) {
      const userAchievements = await db
        .select()
        .from(achievements)
        .where(eq(achievements.profileId, parseInt(profileId)))
        .orderBy(desc(achievements.dateAchieved))

      return NextResponse.json(userAchievements)
    }

    const allAchievements = await db
      .select()
      .from(achievements)
      .orderBy(desc(achievements.dateAchieved))

    return NextResponse.json(allAchievements)
  } catch (error: any) {
    console.error('Achievement fetch error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch achievements' },
      { status: 500 }
    )
  }
}