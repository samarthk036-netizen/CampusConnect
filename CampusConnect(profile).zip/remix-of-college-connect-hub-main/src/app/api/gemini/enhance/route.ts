import { NextRequest, NextResponse } from 'next/server'
import { enhanceAchievementDescription, generateCommunityDescription } from '@/lib/gemini'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, title, description, category, name } = body

    if (type === 'achievement') {
      if (!title || !description) {
        return NextResponse.json(
          { error: 'Title and description are required' },
          { status: 400 }
        )
      }

      const enhanced = await enhanceAchievementDescription(title, description, body.achievementType || 'achievement')
      return NextResponse.json({ enhanced })
    } else if (type === 'community') {
      if (!name || !category) {
        return NextResponse.json(
          { error: 'Name and category are required' },
          { status: 400 }
        )
      }

      const description = await generateCommunityDescription(name, category)
      return NextResponse.json({ description })
    }

    return NextResponse.json(
      { error: 'Invalid type' },
      { status: 400 }
    )
  } catch (error: any) {
    console.error('Enhancement API error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to enhance content' },
      { status: 500 }
    )
  }
}
