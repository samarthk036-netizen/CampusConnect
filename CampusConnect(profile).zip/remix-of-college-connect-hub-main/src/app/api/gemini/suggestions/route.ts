import { NextRequest, NextResponse } from 'next/server'
import { generatePostSuggestions } from '@/lib/gemini'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { topic } = body

    if (!topic) {
      return NextResponse.json(
        { error: 'Topic is required' },
        { status: 400 }
      )
    }

    const suggestions = await generatePostSuggestions(topic)

    return NextResponse.json({ suggestions })
  } catch (error: any) {
    console.error('Suggestions API error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to generate suggestions' },
      { status: 500 }
    )
  }
}
