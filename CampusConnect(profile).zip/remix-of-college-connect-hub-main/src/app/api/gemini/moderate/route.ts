import { NextRequest, NextResponse } from 'next/server'
import { moderateContent } from '@/lib/gemini'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { content } = body

    if (!content) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      )
    }

    const result = await moderateContent(content)

    return NextResponse.json(result)
  } catch (error: any) {
    console.error('Moderation API error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to moderate content' },
      { status: 500 }
    )
  }
}
