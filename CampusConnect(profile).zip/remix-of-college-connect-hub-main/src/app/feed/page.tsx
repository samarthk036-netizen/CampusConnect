"use client"

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { useAuth } from '@/hooks/useAuth'
import { Heart, MessageCircle, Send, Plus, Calendar, Megaphone, Loader2, AlertTriangle, Sparkles } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface Post {
  id: number
  userId: string
  content: string
  imageUrl: string | null
  postType: string
  likesCount: number
  commentsCount: number
  createdAt: string
  userFullName?: string
  userAvatarUrl?: string | null
  isLiked?: boolean
}

export default function FeedPage() {
  const { user, profile, loading: authLoading } = useAuth()
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [moderating, setModerating] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [moderationWarning, setModerationWarning] = useState<string | null>(null)
  const [newPost, setNewPost] = useState({
    content: '',
    postType: 'general',
    imageUrl: ''
  })
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login')
    } else if (user) {
      fetchPosts()
    }
  }, [user, authLoading])

  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/posts')
      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreatePost = async () => {
    if (!newPost.content.trim()) return

    // Moderate content before posting
    setModerating(true)
    setModerationWarning(null)

    try {
      const moderationResponse = await fetch('/api/gemini/moderate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newPost.content }),
      })

      if (moderationResponse.ok) {
        const moderation = await moderationResponse.json()
        
        if (!moderation.isAppropriate) {
          setModerationWarning(moderation.reason || 'This content may not be appropriate for the community.')
          setModerating(false)
          return
        }
      }
    } catch (error) {
      console.error('Moderation error:', error)
      // Continue posting even if moderation fails
    }

    setModerating(false)
    setCreating(true)
    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          content: newPost.content,
          imageUrl: newPost.imageUrl || null,
          postType: newPost.postType,
        }),
      })

      if (response.ok) {
        setNewPost({ content: '', postType: 'general', imageUrl: '' })
        setDialogOpen(false)
        setModerationWarning(null)
        fetchPosts()
      }
    } catch (error) {
      console.error('Error creating post:', error)
    } finally {
      setCreating(false)
    }
  }

  const handleLike = async (postId: number) => {
    try {
      const response = await fetch('/api/posts/like', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId, userId: user?.id }),
      })

      if (response.ok) {
        fetchPosts()
      }
    } catch (error) {
      console.error('Error liking post:', error)
    }
  }

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'announcement':
        return <Megaphone className="h-4 w-4" />
      case 'event':
        return <Calendar className="h-4 w-4" />
      default:
        return null
    }
  }

  const getPostTypeBadge = (type: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      announcement: "destructive",
      event: "default",
      general: "secondary"
    }
    return (
      <Badge variant={variants[type] || "secondary"} className="flex items-center gap-1">
        {getPostTypeIcon(type)}
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </Badge>
    )
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-muted/30">
        <div className="max-w-2xl mx-auto p-4 space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader className="flex-row items-center gap-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Create Post Card */}
        <Card>
          <CardContent className="pt-6">
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full" size="lg">
                  <Plus className="h-5 w-5 mr-2" />
                  Create New Post
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[525px]">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    Create Post
                    <Badge variant="outline" className="gap-1">
                      <Sparkles className="h-3 w-3" />
                      AI Moderated
                    </Badge>
                  </DialogTitle>
                  <DialogDescription>
                    Share an update, announcement, or event with your college community
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {moderationWarning && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{moderationWarning}</AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Post Type</label>
                    <Select value={newPost.postType} onValueChange={(value) => setNewPost({ ...newPost, postType: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="announcement">Announcement</SelectItem>
                        <SelectItem value="event">Event</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Content</label>
                    <Textarea
                      placeholder="What's on your mind?"
                      value={newPost.content}
                      onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Image URL (optional)</label>
                    <input
                      type="url"
                      className="w-full px-3 py-2 border rounded-md"
                      placeholder="https://example.com/image.jpg"
                      value={newPost.imageUrl}
                      onChange={(e) => setNewPost({ ...newPost, imageUrl: e.target.value })}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreatePost} disabled={creating || moderating || !newPost.content.trim()}>
                    {moderating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Checking...
                      </>
                    ) : creating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Posting...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Post
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Posts Feed */}
        {posts.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              No posts yet. Be the first to share something!
            </CardContent>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={post.userAvatarUrl || undefined} />
                      <AvatarFallback>
                        {post.userFullName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{post.userFullName || 'Unknown User'}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  {getPostTypeBadge(post.postType)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="whitespace-pre-wrap">{post.content}</p>
                {post.imageUrl && (
                  <img
                    src={post.imageUrl}
                    alt="Post image"
                    className="w-full rounded-lg object-cover max-h-96"
                  />
                )}
              </CardContent>
              <CardFooter className="flex items-center gap-4 pt-0">
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-2"
                  onClick={() => handleLike(post.id)}
                >
                  <Heart className={`h-5 w-5 ${post.isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                  <span>{post.likesCount}</span>
                </Button>
                <Button variant="ghost" size="sm" className="gap-2">
                  <MessageCircle className="h-5 w-5" />
                  <span>{post.commentsCount}</span>
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}