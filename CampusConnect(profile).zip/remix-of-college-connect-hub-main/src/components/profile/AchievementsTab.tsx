// Achievements Tab - Showcase milestones, awards, projects, and endorsements
"use client"

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { 
  Trophy, 
  Award, 
  Star, 
  Target,
  Zap,
  Plus,
  Calendar,
  ExternalLink,
  FileText,
  Image as ImageIcon,
  Medal,
  ThumbsUp,
  Users,
  Briefcase,
  Code,
  GraduationCap,
  Edit,
  Trash2
} from "lucide-react";
import { format } from "date-fns";

interface Achievement {
  id: number;
  title: string;
  description: string;
  achievementType: string;
  dateAchieved: string;
  imageUrl: string | null;
  fileUrl?: string | null;
  endorsements?: number;
}

interface AchievementsTabProps {
  achievements: Achievement[];
  isOwnProfile?: boolean;
  onAdd?: () => void;
}

const achievementTypeConfig = {
  technical: { icon: Zap, label: "Technical", color: "bg-blue-500", borderColor: "border-blue-200" },
  academic: { icon: GraduationCap, label: "Academic", color: "bg-green-500", borderColor: "border-green-200" },
  sports: { icon: Trophy, label: "Sports", color: "bg-orange-500", borderColor: "border-orange-200" },
  cultural: { icon: Star, label: "Cultural", color: "bg-purple-500", borderColor: "border-purple-200" },
  leadership: { icon: Target, label: "Leadership", color: "bg-red-500", borderColor: "border-red-200" },
  certification: { icon: Award, label: "Certification", color: "bg-indigo-500", borderColor: "border-indigo-200" },
  project: { icon: Code, label: "Project", color: "bg-cyan-500", borderColor: "border-cyan-200" },
  internship: { icon: Briefcase, label: "Internship", color: "bg-pink-500", borderColor: "border-pink-200" },
  other: { icon: Medal, label: "Other", color: "bg-gray-500", borderColor: "border-gray-200" },
};

export function AchievementsTab({ achievements, isOwnProfile, onAdd }: AchievementsTabProps) {
  const [endorsedAchievements, setEndorsedAchievements] = useState<Set<number>>(new Set());

  // Mock endorsers data
  const mockEndorsers = [
    { id: 1, name: "Dr. Sarah Johnson", role: "Professor", avatar: null },
    { id: 2, name: "Rahul Sharma", role: "Senior Student", avatar: null },
    { id: 3, name: "Prof. Amit Kumar", role: "HOD", avatar: null },
  ];

  const handleEndorse = (achievementId: number) => {
    setEndorsedAchievements(prev => {
      const newSet = new Set(prev);
      if (newSet.has(achievementId)) {
        newSet.delete(achievementId);
      } else {
        newSet.add(achievementId);
      }
      return newSet;
    });
  };

  // Mock milestones
  const milestones = [
    { id: 1, title: "Joined Campus Connect", date: "2023-08-15", icon: Users, completed: true },
    { id: 2, title: "First Achievement Added", date: "2023-09-10", icon: Trophy, completed: true },
    { id: 3, title: "10+ Connections", date: "2023-10-05", icon: Users, completed: true },
    { id: 4, title: "5+ Achievements", date: "2024-01-20", icon: Medal, completed: achievements.length >= 5 },
    { id: 5, title: "50+ Endorsements", date: null, icon: ThumbsUp, completed: false },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Achievements & Milestones</h2>
          <p className="text-muted-foreground">Showcase your accomplishments and proud moments</p>
        </div>
        {isOwnProfile && (
          <Button onClick={onAdd}>
            <Plus className="w-4 h-4 mr-2" />
            Add Achievement
          </Button>
        )}
      </div>

      {/* Milestones Progress */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Medal className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Your Milestones</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {milestones.map((milestone) => {
            const Icon = milestone.icon;
            return (
              <div
                key={milestone.id}
                className={`text-center p-4 rounded-lg border-2 transition-all ${
                  milestone.completed
                    ? "bg-primary/5 border-primary"
                    : "bg-muted/50 border-muted opacity-60"
                }`}
              >
                <div
                  className={`w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-2 ${
                    milestone.completed ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <p className="text-xs font-medium">{milestone.title}</p>
                {milestone.date && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {format(new Date(milestone.date), "MMM yyyy")}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      {/* Achievements Grid */}
      {achievements.length === 0 ? (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            <Trophy className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No achievements yet</h3>
            <p className="mb-4">Start showcasing your accomplishments and milestones</p>
            {isOwnProfile && (
              <Button onClick={onAdd} variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Achievement
              </Button>
            )}
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {achievements.map((achievement) => {
            const config = achievementTypeConfig[achievement.achievementType as keyof typeof achievementTypeConfig] || achievementTypeConfig.other;
            const Icon = config.icon;
            const isEndorsed = endorsedAchievements.has(achievement.id);
            const endorsementCount = (achievement.endorsements || 0) + (isEndorsed ? 1 : 0);

            return (
              <Card key={achievement.id} className={`overflow-hidden border-2 ${config.borderColor} hover:shadow-lg transition-all`}>
                {/* Achievement Header with Image/Icon */}
                {achievement.imageUrl ? (
                  <div className="relative h-48 bg-muted">
                    <img
                      src={achievement.imageUrl}
                      alt={achievement.title}
                      className="w-full h-full object-cover"
                    />
                    <Badge className={`absolute top-3 right-3 ${config.color} text-white border-0`}>
                      <Icon className="w-3 h-3 mr-1" />
                      {config.label}
                    </Badge>
                  </div>
                ) : (
                  <div className={`h-32 ${config.color} flex items-center justify-center relative`}>
                    <Icon className="w-16 h-16 text-white opacity-90" />
                    <Badge className="absolute top-3 right-3 bg-white/20 text-white border-0 backdrop-blur-sm">
                      {config.label}
                    </Badge>
                  </div>
                )}

                {/* Achievement Content */}
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-bold text-lg leading-tight">{achievement.title}</h3>
                    {isOwnProfile && (
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                    {achievement.description}
                  </p>

                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(achievement.dateAchieved), "MMMM dd, yyyy")}
                  </div>

                  {/* Attachments */}
                  {achievement.fileUrl && (
                    <Button variant="outline" size="sm" className="w-full mb-4">
                      <FileText className="w-4 h-4 mr-2" />
                      View Certificate
                      <ExternalLink className="w-3 h-3 ml-auto" />
                    </Button>
                  )}

                  {/* Endorsements */}
                  <div className="pt-4 border-t">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <ThumbsUp className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm font-medium">
                          {endorsementCount} {endorsementCount === 1 ? "Endorsement" : "Endorsements"}
                        </span>
                      </div>
                      {!isOwnProfile && (
                        <Button
                          variant={isEndorsed ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleEndorse(achievement.id)}
                        >
                          <ThumbsUp className={`w-3 h-3 mr-1 ${isEndorsed ? "fill-current" : ""}`} />
                          {isEndorsed ? "Endorsed" : "Endorse"}
                        </Button>
                      )}
                    </div>

                    {/* Endorsers List */}
                    {endorsementCount > 0 && (
                      <div className="flex items-center gap-2">
                        <div className="flex -space-x-2">
                          {mockEndorsers.slice(0, 3).map((endorser, idx) => (
                            <Avatar key={idx} className="w-7 h-7 border-2 border-background">
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white text-xs font-semibold">
                                {endorser.name.charAt(0)}
                              </div>
                            </Avatar>
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {mockEndorsers[0].name} and {endorsementCount - 1} others
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Request Endorsement Section - Only for own profile */}
      {isOwnProfile && achievements.length > 0 && (
        <Card className="p-6 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-primary/10 rounded-full">
              <ThumbsUp className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-2">Request Endorsements</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Ask your professors, mentors, or peers to endorse your achievements and add credibility to your profile.
              </p>
              <Button variant="outline">
                <Users className="w-4 h-4 mr-2" />
                Request Endorsement
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
