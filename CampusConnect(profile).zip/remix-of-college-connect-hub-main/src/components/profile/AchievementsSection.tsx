"use client"

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Trophy, 
  Award, 
  Star, 
  Target,
  Zap,
  Plus,
  Calendar
} from "lucide-react";
import { format } from "date-fns";

interface Achievement {
  id: number;
  profileId: number;
  title: string;
  description: string | null;
  achievementType: string;
  dateAchieved: string;
  imageUrl: string | null;
  createdAt: string;
}

interface AchievementsSectionProps {
  achievements: Achievement[];
  isOwnProfile?: boolean;
  onAdd?: () => void;
}

const achievementTypeConfig = {
  technical: { icon: Zap, label: "Technical", color: "bg-blue-500" },
  academic: { icon: Award, label: "Academic", color: "bg-green-500" },
  sports: { icon: Trophy, label: "Sports", color: "bg-orange-500" },
  cultural: { icon: Star, label: "Cultural", color: "bg-purple-500" },
  leadership: { icon: Target, label: "Leadership", color: "bg-red-500" },
  other: { icon: Award, label: "Other", color: "bg-gray-500" },
};

export function AchievementsSection({ 
  achievements, 
  isOwnProfile,
  onAdd 
}: AchievementsSectionProps) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Achievements</h2>
        {isOwnProfile && (
          <Button onClick={onAdd} size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Achievement
          </Button>
        )}
      </div>

      {achievements.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Trophy className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No achievements yet</p>
          {isOwnProfile && (
            <Button onClick={onAdd} variant="outline" size="sm" className="mt-4">
              Add your first achievement
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {achievements.map((achievement) => {
            const config = achievementTypeConfig[achievement.achievementType as keyof typeof achievementTypeConfig] || achievementTypeConfig.other;
            const Icon = config.icon;

            return (
              <div
                key={achievement.id}
                className="flex gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                {achievement.imageUrl ? (
                  <img
                    src={achievement.imageUrl}
                    alt={achievement.title}
                    className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                  />
                ) : (
                  <div className={`w-20 h-20 rounded-lg ${config.color} flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-10 h-10 text-white" />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold">{achievement.title}</h3>
                    <Badge variant="secondary" className="flex-shrink-0">
                      {config.label}
                    </Badge>
                  </div>

                  {achievement.description && (
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                      {achievement.description}
                    </p>
                  )}

                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(achievement.dateAchieved), 'MMM dd, yyyy')}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
