// Student Profile Tab - Comprehensive profile information
"use client"

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  User, 
  Users, 
  BookOpen, 
  Briefcase, 
  GraduationCap,
  Lock,
  Unlock,
  Settings,
  Tag,
  Heart,
  UserPlus,
  UserMinus
} from "lucide-react";

interface Profile {
  id: number;
  fullName: string;
  email: string;
  usnOrFacultyId: string;
  userType: string;
  department: string;
  yearOrDesignation: string;
  bio: string | null;
  profileImageUrl: string | null;
  location: string | null;
  website: string | null;
}

interface StudentProfileTabProps {
  profile: Profile;
  isOwnProfile?: boolean;
}

export function StudentProfileTab({ profile, isOwnProfile }: StudentProfileTabProps) {
  // Mock data - would come from API in production
  const skills = ["React", "TypeScript", "Node.js", "Python", "Machine Learning", "Data Structures"];
  const interests = ["Web Development", "AI/ML", "Photography", "Gaming", "Music", "Fitness"];
  const clubs = [
    { id: 1, name: "Coding Club", role: "Member" },
    { id: 2, name: "Photography Club", role: "President" },
    { id: 3, name: "Music Society", role: "Member" }
  ];
  const courses = [
    { id: 1, name: "Data Structures & Algorithms", code: "CS301", grade: "A" },
    { id: 2, name: "Database Management Systems", code: "CS302", grade: "A+" },
    { id: 3, name: "Web Technologies", code: "CS303", grade: "A" }
  ];
  const projects = [
    { id: 1, name: "Campus Connect App", tech: "Next.js, TypeScript", status: "Completed" },
    { id: 2, name: "ML Image Classifier", tech: "Python, TensorFlow", status: "In Progress" }
  ];
  const connections = {
    followers: 234,
    following: 156
  };

  return (
    <div className="space-y-6">
      {/* Skills & Interests */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Skills */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold">Skills</h3>
            </div>
            {isOwnProfile && (
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <Badge key={index} variant="secondary" className="px-3 py-1">
                {skill}
              </Badge>
            ))}
            {isOwnProfile && (
              <Button variant="outline" size="sm" className="h-7">
                + Add Skill
              </Button>
            )}
          </div>
        </Card>

        {/* Interests */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold">Interests</h3>
            </div>
            {isOwnProfile && (
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {interests.map((interest, index) => (
              <Badge key={index} variant="outline" className="px-3 py-1">
                {interest}
              </Badge>
            ))}
            {isOwnProfile && (
              <Button variant="outline" size="sm" className="h-7">
                + Add Interest
              </Button>
            )}
          </div>
        </Card>
      </div>

      {/* Academic Info */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <GraduationCap className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Academic Information</h3>
        </div>
        
        <div className="space-y-4">
          {/* Current Courses */}
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-3">Current Courses</h4>
            <div className="space-y-2">
              {courses.map((course) => (
                <div key={course.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{course.name}</p>
                      <p className="text-sm text-muted-foreground">{course.code}</p>
                    </div>
                  </div>
                  <Badge variant="default">{course.grade}</Badge>
                </div>
              ))}
            </div>
          </div>

          {/* Projects */}
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-3">Projects & Internships</h4>
            <div className="space-y-2">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Briefcase className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{project.name}</p>
                      <p className="text-sm text-muted-foreground">{project.tech}</p>
                    </div>
                  </div>
                  <Badge variant="secondary">{project.status}</Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Clubs & Groups */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Clubs & Groups</h3>
        </div>
        <div className="space-y-2">
          {clubs.map((club) => (
            <div key={club.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                  {club.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium">{club.name}</p>
                  <p className="text-sm text-muted-foreground">{club.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm">View</Button>
            </div>
          ))}
        </div>
      </Card>

      {/* Connections */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <User className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Connections</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <p className="text-2xl font-bold text-primary">{connections.followers}</p>
            <p className="text-sm text-muted-foreground">Followers</p>
          </div>
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <p className="text-2xl font-bold text-primary">{connections.following}</p>
            <p className="text-sm text-muted-foreground">Following</p>
          </div>
        </div>
        {!isOwnProfile && (
          <div className="flex gap-2 mt-4">
            <Button className="flex-1">
              <UserPlus className="w-4 h-4 mr-2" />
              Follow
            </Button>
            <Button variant="outline" className="flex-1">
              Message
            </Button>
          </div>
        )}
      </Card>

      {/* Privacy Controls - Only for own profile */}
      {isOwnProfile && (
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Privacy & Settings</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Unlock className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="font-medium">Profile Visibility</p>
                  <p className="text-sm text-muted-foreground">Who can view your profile</p>
                </div>
              </div>
              <Badge variant="secondary">Everyone</Badge>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Lock className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="font-medium">Contact Information</p>
                  <p className="text-sm text-muted-foreground">Who can see your email</p>
                </div>
              </div>
              <Badge variant="secondary">Connections Only</Badge>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
