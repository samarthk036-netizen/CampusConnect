"use client"

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  MapPin, 
  Link as LinkIcon, 
  Calendar, 
  Briefcase,
  GraduationCap,
  Mail,
  CheckCircle2
} from "lucide-react";
import { format } from "date-fns";

interface Profile {
  id: number;
  fullName: string;
  email: string;
  usnOrFacultyId: string;
  userType: string;
  department: string;
  yearOrDesignation: string;
  bio: string | null;
  profileImageUrl: string | null;
  coverImageUrl: string | null;
  location: string | null;
  website: string | null;
  createdAt: string;
}

interface ProfileHeaderProps {
  profile: Profile;
  isOwnProfile?: boolean;
  onEdit?: () => void;
}

export function ProfileHeader({ profile, isOwnProfile, onEdit }: ProfileHeaderProps) {
  return (
    <Card className="overflow-hidden">
      {/* Cover Image */}
      <div className="h-48 sm:h-64 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 relative">
        {profile.coverImageUrl && (
          <img
            src={profile.coverImageUrl}
            alt="Cover"
            className="w-full h-full object-cover"
          />
        )}
      </div>

      <div className="px-4 sm:px-6 pb-6">
        <div className="flex flex-col sm:flex-row sm:items-end gap-4">
          {/* Profile Image */}
          <div className="relative flex-shrink-0 -mt-16 sm:-mt-20">
            <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-4 border-background bg-muted overflow-hidden shadow-xl">
              {profile.profileImageUrl ? (
                <img
                  src={profile.profileImageUrl}
                  alt={profile.fullName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white text-4xl font-bold">
                  {profile.fullName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <Badge 
              variant={profile.userType === 'student' ? 'default' : 'secondary'}
              className="absolute bottom-2 right-2 shadow-md"
            >
              {profile.userType === 'student' ? 'Student' : 'Faculty'}
            </Badge>
          </div>

          {/* Profile Info - Properly spaced */}
          <div className="flex-1 sm:pb-4">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-2xl sm:text-3xl font-bold text-foreground">{profile.fullName}</h1>
                  <CheckCircle2 className="w-5 h-5 text-blue-500 flex-shrink-0" />
                </div>
                <p className="text-base text-muted-foreground mt-1">
                  {profile.userType === 'student' ? `Year ${profile.yearOrDesignation}` : profile.yearOrDesignation}
                  {' • '}
                  {profile.department}
                </p>
              </div>
              {isOwnProfile && (
                <Button onClick={onEdit} variant="outline" size="sm" className="flex-shrink-0">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>

            {/* Bio */}
            {profile.bio && (
              <p className="mt-3 text-muted-foreground leading-relaxed">{profile.bio}</p>
            )}

            {/* Details */}
            <div className="mt-4 flex flex-wrap gap-3 sm:gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{profile.email}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {profile.userType === 'student' ? (
                  <GraduationCap className="w-4 h-4 flex-shrink-0" />
                ) : (
                  <Briefcase className="w-4 h-4 flex-shrink-0" />
                )}
                {profile.usnOrFacultyId}
              </div>
              {profile.location && (
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  {profile.location}
                </div>
              )}
              {profile.website && (
                <a
                  href={profile.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-primary transition-colors"
                >
                  <LinkIcon className="w-4 h-4 flex-shrink-0" />
                  Website
                </a>
              )}
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 flex-shrink-0" />
                Joined {format(new Date(profile.createdAt), 'MMM yyyy')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}