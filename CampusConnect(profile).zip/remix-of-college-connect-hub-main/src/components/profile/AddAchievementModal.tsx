"use client"

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";

const achievementSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().max(500, "Description must be less than 500 characters").optional(),
  achievementType: z.enum(["technical", "academic", "sports", "cultural", "leadership", "other"]),
  dateAchieved: z.string().min(1, "Date is required"),
  imageUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type AchievementFormData = z.infer<typeof achievementSchema>;

interface AddAchievementModalProps {
  isOpen: boolean;
  onClose: () => void;
  profileId: number;
  onSuccess: () => void;
}

export function AddAchievementModal({ 
  isOpen, 
  onClose, 
  profileId, 
  onSuccess 
}: AddAchievementModalProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<AchievementFormData>({
    resolver: zodResolver(achievementSchema),
    defaultValues: {
      title: "",
      description: "",
      achievementType: "technical",
      dateAchieved: new Date().toISOString().split("T")[0],
      imageUrl: "",
    },
  });

  const generateDescription = async () => {
    const title = watch("title");
    const type = watch("achievementType");

    if (!title) {
      toast.error("Please enter a title first");
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch("/api/ai/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "achievement",
          context: {
            title,
            achievementType: type,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to generate description");

      const data = await response.json();
      setValue("description", data.suggestion);
      toast.success("Description generated!");
    } catch (error) {
      toast.error("Failed to generate description");
    } finally {
      setIsGenerating(false);
    }
  };

  const onSubmit = async (data: AchievementFormData) => {
    try {
      const response = await fetch("/api/achievements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profileId,
          title: data.title,
          description: data.description || null,
          achievementType: data.achievementType,
          dateAchieved: new Date(data.dateAchieved).toISOString(),
          imageUrl: data.imageUrl || null,
        }),
      });

      if (!response.ok) throw new Error("Failed to create achievement");

      toast.success("Achievement added successfully!");
      reset();
      onClose();
      onSuccess();
    } catch (error) {
      toast.error("Failed to add achievement");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Achievement</DialogTitle>
          <DialogDescription>
            Celebrate your accomplishments and milestones
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Achievement Title</Label>
            <Input
              id="title"
              {...register("title")}
              placeholder="e.g., Winner - Smart India Hackathon 2024"
            />
            {errors.title && (
              <p className="text-sm text-destructive">{errors.title.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="achievementType">Type</Label>
            <Select
              value={watch("achievementType")}
              onValueChange={(value) => setValue("achievementType", value as any)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select achievement type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="technical">Technical</SelectItem>
                <SelectItem value="academic">Academic</SelectItem>
                <SelectItem value="sports">Sports</SelectItem>
                <SelectItem value="cultural">Cultural</SelectItem>
                <SelectItem value="leadership">Leadership</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            {errors.achievementType && (
              <p className="text-sm text-destructive">{errors.achievementType.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="description">Description</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={generateDescription}
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4 mr-2" />
                )}
                AI Suggest
              </Button>
            </div>
            <Textarea
              id="description"
              {...register("description")}
              placeholder="Describe your achievement, its impact, and what you learned..."
              rows={4}
              className="resize-none"
            />
            {errors.description && (
              <p className="text-sm text-destructive">{errors.description.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="dateAchieved">Date Achieved</Label>
            <Input
              id="dateAchieved"
              {...register("dateAchieved")}
              type="date"
              max={new Date().toISOString().split("T")[0]}
            />
            {errors.dateAchieved && (
              <p className="text-sm text-destructive">{errors.dateAchieved.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl">Image URL (optional)</Label>
            <Input
              id="imageUrl"
              {...register("imageUrl")}
              placeholder="https://example.com/certificate.jpg"
              type="url"
            />
            {errors.imageUrl && (
              <p className="text-sm text-destructive">{errors.imageUrl.message}</p>
            )}
          </div>

          {watch("imageUrl") && (
            <div className="rounded-lg border overflow-hidden">
              <img
                src={watch("imageUrl")}
                alt="Preview"
                className="w-full h-48 object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://placehold.co/600x400?text=Invalid+Image+URL";
                }}
              />
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Add Achievement
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
