// Community Tab - Find and join groups, clubs, and communities
"use client"

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/ui/avatar";
import { 
  Users, 
  Search,
  Plus,
  MessageCircle,
  Calendar,
  FolderOpen,
  TrendingUp,
  Lock,
  Unlock,
  Settings,
  UserPlus,
  UserMinus,
  BookOpen,
  Coffee,
  Car,
  Dumbbell,
  Music,
  Code,
  Camera,
  Palette,
  Globe
} from "lucide-react";

interface Community {
  id: number;
  name: string;
  description: string;
  category: string;
  memberCount: number;
  isPrivate: boolean;
  isMember: boolean;
  avatarUrl: string | null;
  recentActivity?: string;
}

interface CommunityTabProps {
  isOwnProfile?: boolean;
}

const categoryIcons = {
  study: BookOpen,
  hobby: Coffee,
  club: Users,
  carpool: Car,
  sports: Dumbbell,
  music: Music,
  tech: Code,
  photography: Camera,
  art: Palette,
  other: Globe,
};

export function CommunityTab({ isOwnProfile }: CommunityTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showJoinedOnly, setShowJoinedOnly] = useState(false);

  // Mock communities data
  const allCommunities: Community[] = [
    {
      id: 1,
      name: "Coding Club",
      description: "Learn, build, and share coding projects together",
      category: "tech",
      memberCount: 234,
      isPrivate: false,
      isMember: true,
      avatarUrl: null,
      recentActivity: "Active 2h ago"
    },
    {
      id: 2,
      name: "Photography Society",
      description: "Capture moments, share techniques, organize photo walks",
      category: "photography",
      memberCount: 156,
      isPrivate: false,
      isMember: true,
      avatarUrl: null,
      recentActivity: "Active 5h ago"
    },
    {
      id: 3,
      name: "Campus Carpool",
      description: "Find rides to and from college, save money and environment",
      category: "carpool",
      memberCount: 89,
      isPrivate: false,
      isMember: false,
      avatarUrl: null,
      recentActivity: "Active 1h ago"
    },
    {
      id: 4,
      name: "Data Science Study Group",
      description: "Weekly meetings to learn ML, AI, and data analytics",
      category: "study",
      memberCount: 67,
      isPrivate: false,
      isMember: true,
      avatarUrl: null,
      recentActivity: "Active 3h ago"
    },
    {
      id: 5,
      name: "Music Band",
      description: "College band for events and jam sessions",
      category: "music",
      memberCount: 23,
      isPrivate: true,
      isMember: false,
      avatarUrl: null,
      recentActivity: "Active 12h ago"
    },
    {
      id: 6,
      name: "Fitness Enthusiasts",
      description: "Workout together, share fitness tips and nutrition advice",
      category: "sports",
      memberCount: 142,
      isPrivate: false,
      isMember: false,
      avatarUrl: null,
      recentActivity: "Active 30m ago"
    },
  ];

  const categories = [
    { id: "all", label: "All Communities", icon: Globe },
    { id: "study", label: "Study Groups", icon: BookOpen },
    { id: "club", label: "Clubs", icon: Users },
    { id: "tech", label: "Tech", icon: Code },
    { id: "sports", label: "Sports", icon: Dumbbell },
    { id: "hobby", label: "Hobbies", icon: Coffee },
  ];

  const filteredCommunities = allCommunities.filter(community => {
    const matchesSearch = community.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         community.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || community.category === selectedCategory;
    const matchesJoined = !showJoinedOnly || community.isMember;
    return matchesSearch && matchesCategory && matchesJoined;
  });

  const joinedCommunities = allCommunities.filter(c => c.isMember);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Communities</h2>
          <p className="text-muted-foreground">
            You're a member of {joinedCommunities.length} {joinedCommunities.length === 1 ? "community" : "communities"}
          </p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Create Community
        </Button>
      </div>

      {/* Search and Filters */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search communities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button
            variant={showJoinedOnly ? "default" : "outline"}
            onClick={() => setShowJoinedOnly(!showJoinedOnly)}
          >
            <Users className="w-4 h-4 mr-2" />
            My Communities
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="flex-shrink-0"
              >
                <Icon className="w-4 h-4 mr-2" />
                {category.label}
              </Button>
            );
          })}
        </div>
      </Card>

      {/* Communities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCommunities.map((community) => {
          const CategoryIcon = categoryIcons[community.category as keyof typeof categoryIcons] || Globe;
          
          return (
            <Card key={community.id} className="overflow-hidden hover:shadow-lg transition-all">
              {/* Community Header */}
              <div className="h-24 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 relative">
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute top-3 right-3">
                  {community.isPrivate ? (
                    <Badge className="bg-black/40 text-white border-0 backdrop-blur-sm">
                      <Lock className="w-3 h-3 mr-1" />
                      Private
                    </Badge>
                  ) : (
                    <Badge className="bg-black/40 text-white border-0 backdrop-blur-sm">
                      <Unlock className="w-3 h-3 mr-1" />
                      Public
                    </Badge>
                  )}
                </div>
              </div>

              {/* Community Avatar */}
              <div className="px-5 -mt-10">
                <div className="w-20 h-20 rounded-full bg-background border-4 border-background flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg">
                  <CategoryIcon className="w-10 h-10" />
                </div>
              </div>

              {/* Community Info */}
              <div className="p-5 pt-3">
                <h3 className="font-bold text-lg mb-2">{community.name}</h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {community.description}
                </p>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {community.memberCount}
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {categories.find(c => c.id === community.category)?.label || "Other"}
                    </Badge>
                  </div>
                </div>

                {community.recentActivity && (
                  <p className="text-xs text-muted-foreground mb-4">
                    <TrendingUp className="w-3 h-3 inline mr-1" />
                    {community.recentActivity}
                  </p>
                )}

                {/* Action Buttons */}
                {community.isMember ? (
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Open Chat
                    </Button>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <Button className="w-full" size="sm">
                    <UserPlus className="w-4 h-4 mr-2" />
                    {community.isPrivate ? "Request to Join" : "Join Community"}
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {filteredCommunities.length === 0 && (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            <Search className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No communities found</h3>
            <p className="mb-4">Try adjusting your search or filters</p>
            <Button variant="outline" onClick={() => { setSearchTerm(""); setSelectedCategory("all"); }}>
              Clear Filters
            </Button>
          </div>
        </Card>
      )}

      {/* Featured Section - Community Resources */}
      {joinedCommunities.length > 0 && (
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <FolderOpen className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Upcoming Events & Resources</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">Weekly Coding Workshop</p>
                  <p className="text-sm text-muted-foreground">Coding Club • Tomorrow at 5:00 PM</p>
                </div>
              </div>
              <Button variant="outline" size="sm">View</Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Camera className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">Campus Photo Walk</p>
                  <p className="text-sm text-muted-foreground">Photography Society • This Saturday</p>
                </div>
              </div>
              <Button variant="outline" size="sm">View</Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
