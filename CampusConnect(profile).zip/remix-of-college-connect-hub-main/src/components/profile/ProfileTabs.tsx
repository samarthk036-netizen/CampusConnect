// Main Profile Tabs Component - Manages navigation between all profile sections
"use client"

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Trophy, 
  Users, 
  MessageSquare,
  GraduationCap
} from "lucide-react";
import { StudentProfileTab } from "./StudentProfileTab";
import { AchievementsTab } from "./AchievementsTab";
import { CommunityTab } from "./CommunityTab";
import { SocialFeedTab } from "./SocialFeedTab";

interface Profile {
  id: number;
  fullName: string;
  email: string;
  usnOrFacultyId: string;
  userType: string;
  department: string;
  yearOrDesignation: string;
  bio: string | null;
  profileImageUrl: string | null;
  coverImageUrl: string | null;
  location: string | null;
  website: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Achievement {
  id: number;
  profileId: number;
  title: string;
  description: string | null;
  achievementType: string;
  dateAchieved: string;
  imageUrl: string | null;
  createdAt: string;
}

interface ProfileTabsProps {
  profile: Profile;
  achievements: Achievement[];
  isOwnProfile?: boolean;
  onAddAchievement?: () => void;
}

export function ProfileTabs({ 
  profile, 
  achievements, 
  isOwnProfile,
  onAddAchievement 
}: ProfileTabsProps) {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-4 h-auto p-1">
        <TabsTrigger 
          value="profile" 
          className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 py-2 sm:py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
        >
          <User className="w-4 h-4" />
          <span className="text-xs sm:text-sm">Profile</span>
        </TabsTrigger>
        <TabsTrigger 
          value="achievements"
          className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 py-2 sm:py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
        >
          <Trophy className="w-4 h-4" />
          <span className="text-xs sm:text-sm">Achievements</span>
        </TabsTrigger>
        <TabsTrigger 
          value="community"
          className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 py-2 sm:py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
        >
          <Users className="w-4 h-4" />
          <span className="text-xs sm:text-sm">Community</span>
        </TabsTrigger>
        <TabsTrigger 
          value="feed"
          className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 py-2 sm:py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="text-xs sm:text-sm">Feed</span>
        </TabsTrigger>
      </TabsList>

      <TabsContent value="profile" className="mt-6">
        <StudentProfileTab profile={profile} isOwnProfile={isOwnProfile} />
      </TabsContent>

      <TabsContent value="achievements" className="mt-6">
        <AchievementsTab 
          achievements={achievements} 
          isOwnProfile={isOwnProfile}
          onAdd={onAddAchievement}
        />
      </TabsContent>

      <TabsContent value="community" className="mt-6">
        <CommunityTab isOwnProfile={isOwnProfile} />
      </TabsContent>

      <TabsContent value="feed" className="mt-6">
        <SocialFeedTab isOwnProfile={isOwnProfile} />
      </TabsContent>
    </Tabs>
  );
}
