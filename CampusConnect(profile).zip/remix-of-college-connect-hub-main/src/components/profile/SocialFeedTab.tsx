// Social Feed Tab - Campus timeline with posts, announcements, and interactions
"use client"

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { 
  Heart, 
  MessageCircle, 
  Share2,
  Bookmark,
  MoreVertical,
  Image as ImageIcon,
  Video,
  Smile,
  Send,
  TrendingUp,
  Megaphone,
  Pin,
  CheckCircle2,
  Filter,
  Plus
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Post {
  id: number;
  author: {
    id: number;
    name: string;
    avatar: string | null;
    userType: "student" | "faculty";
    department: string;
    verified: boolean;
  };
  content: string;
  imageUrl?: string | null;
  videoUrl?: string | null;
  type: "post" | "announcement" | "story";
  isPinned?: boolean;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  tags?: string[];
  createdAt: string;
}

interface SocialFeedTabProps {
  isOwnProfile?: boolean;
}

export function SocialFeedTab({ isOwnProfile }: SocialFeedTabProps) {
  const [newPostContent, setNewPostContent] = useState("");
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());
  const [savedPosts, setSavedPosts] = useState<Set<number>>(new Set());
  const [filterType, setFilterType] = useState<"all" | "announcements" | "posts">("all");

  // Mock posts data
  const mockPosts: Post[] = [
    {
      id: 1,
      author: {
        id: 1,
        name: "College Administration",
        avatar: null,
        userType: "faculty",
        department: "Administration",
        verified: true,
      },
      content: "📢 Important: Mid-semester exams will be conducted from December 15-22. Please check your respective department notice boards for detailed schedules. Best of luck to all students!",
      type: "announcement",
      isPinned: true,
      likesCount: 234,
      commentsCount: 45,
      sharesCount: 89,
      tags: ["Exams", "Important"],
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 2,
      author: {
        id: 2,
        name: "Rahul Sharma",
        avatar: null,
        userType: "student",
        department: "Computer Science",
        verified: true,
      },
      content: "Just completed my final year project presentation! 🎉 Built a real-time collaboration platform using Next.js and WebSockets. Huge thanks to Dr. Kumar for the guidance. #FinalYear #WebDev",
      imageUrl: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop",
      type: "post",
      likesCount: 156,
      commentsCount: 23,
      sharesCount: 12,
      tags: ["FinalYear", "WebDev", "Project"],
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 3,
      author: {
        id: 3,
        name: "Dr. Sarah Johnson",
        avatar: null,
        userType: "faculty",
        department: "AI & Data Science",
        verified: true,
      },
      content: "Excited to announce that our college has been selected for the National AI Research Initiative! We'll be collaborating with IIT Delhi on cutting-edge ML projects. Opportunities for interested students coming soon! 🚀",
      type: "announcement",
      likesCount: 345,
      commentsCount: 67,
      sharesCount: 145,
      tags: ["Research", "AI", "Opportunity"],
      createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 4,
      author: {
        id: 4,
        name: "Priya Patel",
        avatar: null,
        userType: "student",
        department: "Photography Club",
        verified: false,
      },
      content: "Golden hour at the campus library 📸✨ Nature has its own way of making everything beautiful. Join us for the photo walk this Saturday!",
      imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&auto=format&fit=crop",
      type: "post",
      likesCount: 89,
      commentsCount: 15,
      sharesCount: 8,
      tags: ["Photography", "Campus"],
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    },
  ];

  const filteredPosts = mockPosts.filter(post => {
    if (filterType === "all") return true;
    if (filterType === "announcements") return post.type === "announcement";
    if (filterType === "posts") return post.type === "post";
    return true;
  });

  const handleLike = (postId: number) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  const handleSave = (postId: number) => {
    setSavedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Social Feed</h2>
          <p className="text-muted-foreground">Stay updated with campus activities and announcements</p>
        </div>
      </div>

      {/* Create Post */}
      <Card className="p-4">
        <div className="flex gap-3">
          <Avatar className="w-10 h-10">
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
              R
            </div>
          </Avatar>
          <div className="flex-1">
            <Textarea
              placeholder="Share something with your campus community..."
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              className="min-h-[80px] resize-none"
            />
            <div className="flex items-center justify-between mt-3">
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Photo
                </Button>
                <Button variant="ghost" size="sm">
                  <Video className="w-4 h-4 mr-2" />
                  Video
                </Button>
                <Button variant="ghost" size="sm">
                  <Smile className="w-4 h-4 mr-2" />
                  Emoji
                </Button>
              </div>
              <Button disabled={!newPostContent.trim()}>
                <Send className="w-4 h-4 mr-2" />
                Post
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <Button
          variant={filterType === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilterType("all")}
        >
          All Posts
        </Button>
        <Button
          variant={filterType === "announcements" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilterType("announcements")}
        >
          <Megaphone className="w-4 h-4 mr-2" />
          Announcements
        </Button>
        <Button
          variant={filterType === "posts" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilterType("posts")}
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Posts
        </Button>
        <Button variant="outline" size="sm">
          <Filter className="w-4 h-4 mr-2" />
          Filter by Department
        </Button>
      </div>

      {/* Posts Feed */}
      <div className="space-y-4">
        {filteredPosts.map((post) => {
          const isLiked = likedPosts.has(post.id);
          const isSaved = savedPosts.has(post.id);
          const displayLikes = post.likesCount + (isLiked ? 1 : 0);

          return (
            <Card key={post.id} className={`overflow-hidden ${post.isPinned ? 'border-primary border-2' : ''}`}>
              {/* Pinned Badge */}
              {post.isPinned && (
                <div className="bg-primary/10 px-4 py-2 border-b flex items-center gap-2">
                  <Pin className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-primary">Pinned Post</span>
                </div>
              )}

              {/* Announcement Badge */}
              {post.type === "announcement" && !post.isPinned && (
                <div className="bg-orange-500/10 px-4 py-2 border-b flex items-center gap-2">
                  <Megaphone className="w-4 h-4 text-orange-600" />
                  <span className="text-sm font-medium text-orange-600">Official Announcement</span>
                </div>
              )}

              <div className="p-4">
                {/* Post Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      {post.author.avatar ? (
                        <img src={post.author.avatar} alt={post.author.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold text-lg">
                          {post.author.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold">{post.author.name}</p>
                        {post.author.verified && (
                          <CheckCircle2 className="w-4 h-4 text-blue-500" />
                        )}
                        <Badge variant="secondary" className="text-xs">
                          {post.author.userType === 'student' ? 'Student' : 'Faculty'}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{post.author.department}</span>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>

                {/* Post Content */}
                <div className="mb-4">
                  <p className="whitespace-pre-wrap leading-relaxed">{post.content}</p>
                  
                  {/* Tags */}
                  {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {post.tags.map((tag, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Post Image */}
                {post.imageUrl && (
                  <div className="mb-4 rounded-lg overflow-hidden -mx-4">
                    <img
                      src={post.imageUrl}
                      alt="Post image"
                      className="w-full h-auto max-h-[500px] object-cover"
                    />
                  </div>
                )}

                {/* Post Stats */}
                <div className="flex items-center gap-4 text-sm text-muted-foreground py-3 border-t border-b">
                  <span>{displayLikes} likes</span>
                  <span>{post.commentsCount} comments</span>
                  <span>{post.sharesCount} shares</span>
                </div>

                {/* Post Actions */}
                <div className="flex items-center gap-2 pt-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`flex-1 ${isLiked ? "text-red-500 hover:text-red-600" : ""}`}
                    onClick={() => handleLike(post.id)}
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isLiked ? "fill-current" : ""}`} />
                    Like
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Comment
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={isSaved ? "text-primary" : ""}
                    onClick={() => handleSave(post.id)}
                  >
                    <Bookmark className={`w-4 h-4 ${isSaved ? "fill-current" : ""}`} />
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Trending Topics */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Trending on Campus</h3>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-lg transition-colors cursor-pointer">
            <div>
              <p className="font-medium text-sm">#TechFest2024</p>
              <p className="text-xs text-muted-foreground">234 posts</p>
            </div>
            <Badge variant="secondary">Trending</Badge>
          </div>
          <div className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-lg transition-colors cursor-pointer">
            <div>
              <p className="font-medium text-sm">#CampusLife</p>
              <p className="text-xs text-muted-foreground">156 posts</p>
            </div>
          </div>
          <div className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-lg transition-colors cursor-pointer">
            <div>
              <p className="font-medium text-sm">#StudyTips</p>
              <p className="text-xs text-muted-foreground">89 posts</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
