"use client"

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  MessageCircle, 
  Share2,
  Plus,
  MoreVertical
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Post {
  id: number;
  profileId: number;
  content: string;
  imageUrl: string | null;
  likesCount: number;
  commentsCount: number;
  createdAt: string;
  updatedAt: string;
}

interface Profile {
  fullName: string;
  profileImageUrl: string | null;
  userType: string;
  department: string;
}

interface PostsFeedProps {
  posts: Post[];
  profile: Profile;
  isOwnProfile?: boolean;
  onAddPost?: () => void;
}

export function PostsFeed({ posts, profile, isOwnProfile, onAddPost }: PostsFeedProps) {
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());

  const handleLike = (postId: number) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) {
        newSet.delete(postId);
      } else {
        newSet.add(postId);
      }
      return newSet;
    });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Posts</h2>
        {isOwnProfile && (
          <Button onClick={onAddPost} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Create Post
          </Button>
        )}
      </div>

      {posts.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No posts yet</p>
          {isOwnProfile && (
            <Button onClick={onAddPost} variant="outline" size="sm" className="mt-4">
              Create your first post
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => {
            const isLiked = likedPosts.has(post.id);
            const displayLikes = post.likesCount + (isLiked ? 1 : 0);

            return (
              <Card key={post.id} className="p-4">
                {/* Post Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      {profile.profileImageUrl ? (
                        <img 
                          src={profile.profileImageUrl} 
                          alt={profile.fullName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
                          {profile.fullName.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </Avatar>
                    <div>
                      <p className="font-semibold">{profile.fullName}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Badge variant="secondary" className="text-xs px-1.5 py-0">
                          {profile.userType === 'student' ? 'Student' : 'Faculty'}
                        </Badge>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>

                {/* Post Content */}
                <div className="mb-4">
                  <p className="whitespace-pre-wrap">{post.content}</p>
                </div>

                {/* Post Image */}
                {post.imageUrl && (
                  <div className="mb-4 rounded-lg overflow-hidden">
                    <img
                      src={post.imageUrl}
                      alt="Post image"
                      className="w-full h-auto max-h-96 object-cover"
                    />
                  </div>
                )}

                {/* Post Actions */}
                <div className="flex items-center gap-4 pt-3 border-t">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(post.id)}
                    className={isLiked ? "text-red-500 hover:text-red-600" : ""}
                  >
                    <Heart 
                      className={`w-4 h-4 mr-2 ${isLiked ? "fill-current" : ""}`}
                    />
                    {displayLikes > 0 && displayLikes}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    {post.commentsCount > 0 && post.commentsCount}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="w-4 h-4 mr-2" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </Card>
  );
}
