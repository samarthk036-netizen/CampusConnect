"use client"

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";

const postSchema = z.object({
  content: z.string().min(1, "Content is required").max(2000, "Content must be less than 2000 characters"),
  imageUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type PostFormData = z.infer<typeof postSchema>;

interface AddPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  profileId: number;
  profile: any;
  onSuccess: () => void;
}

export function AddPostModal({ isOpen, onClose, profileId, profile, onSuccess }: AddPostModalProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<PostFormData>({
    resolver: zodResolver(postSchema),
    defaultValues: {
      content: "",
      imageUrl: "",
    },
  });

  const generatePostIdea = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch("/api/ai/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "post",
          context: {
            userType: profile.userType,
            department: profile.department,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to generate post idea");

      const data = await response.json();
      
      // Try to parse JSON response, otherwise use as plain text
      try {
        const suggestions = JSON.parse(data.suggestion);
        if (Array.isArray(suggestions) && suggestions.length > 0) {
          setValue("content", suggestions[0].content);
        } else {
          setValue("content", data.suggestion);
        }
      } catch {
        setValue("content", data.suggestion);
      }
      
      toast.success("Post idea generated!");
    } catch (error) {
      toast.error("Failed to generate post idea");
    } finally {
      setIsGenerating(false);
    }
  };

  const onSubmit = async (data: PostFormData) => {
    try {
      const response = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profileId,
          content: data.content,
          imageUrl: data.imageUrl || null,
        }),
      });

      if (!response.ok) throw new Error("Failed to create post");

      toast.success("Post created successfully!");
      reset();
      onClose();
      onSuccess();
    } catch (error) {
      toast.error("Failed to create post");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create New Post</DialogTitle>
          <DialogDescription>
            Share your thoughts, updates, or achievements with the community
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="content">What's on your mind?</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={generatePostIdea}
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4 mr-2" />
                )}
                AI Suggest
              </Button>
            </div>
            <Textarea
              id="content"
              {...register("content")}
              placeholder="Share something interesting..."
              rows={6}
              className="resize-none"
            />
            {errors.content && (
              <p className="text-sm text-destructive">{errors.content.message}</p>
            )}
            <p className="text-xs text-muted-foreground">
              {watch("content")?.length || 0} / 2000 characters
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl" className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              Image URL (optional)
            </Label>
            <Input
              id="imageUrl"
              {...register("imageUrl")}
              placeholder="https://example.com/image.jpg"
              type="url"
            />
            {errors.imageUrl && (
              <p className="text-sm text-destructive">{errors.imageUrl.message}</p>
            )}
          </div>

          {watch("imageUrl") && (
            <div className="rounded-lg border overflow-hidden">
              <img
                src={watch("imageUrl")}
                alt="Preview"
                className="w-full h-48 object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://placehold.co/600x400?text=Invalid+Image+URL";
                }}
              />
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Post
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
