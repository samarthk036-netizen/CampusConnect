# Setup Guide 🚀

Complete setup instructions for the College Community Profile Platform.

## Prerequisites

- Node.js 18+ or Bun
- Git
- Google Gemini API Key ([Get one here](https://makersuite.google.com/app/apikey))

## Step-by-Step Setup

### 1. Clone & Install

```bash
# Clone the repository
git clone <your-repo-url>
cd college-community-app

# Install dependencies
npm install
# or if using bun
bun install
```

### 2. Environment Setup

Create a `.env.local` file in the root directory:

```bash
cp .env.example .env.local
```

Edit `.env.local` and add your Gemini API key:

```env
GEMINI_API_KEY=your_actual_api_key_here
```

### 3. Database Setup

Initialize the database:

```bash
# Generate database schema
npm run db:push

# Seed with sample data (15 profiles, 35 achievements, 55 posts)
npm run db:seed
```

### 4. Run Development Server

```bash
npm run dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🎯 Quick Start

### View a Profile
1. Go to http://localhost:3000
2. Click on any demo profile card
3. Or directly visit: http://localhost:3000/profile/1

### Test Profile Editing
1. Visit any profile page
2. Click "Edit Profile"
3. Update information
4. Try "AI Suggest" for bio generation
5. Save changes

### Test Achievement Creation
1. On a profile page, click "Add Achievement"
2. Fill in the form
3. Select achievement type
4. Use "AI Suggest" for description
5. Submit

### Test Post Creation
1. Click "Create Post"
2. Write content or use "AI Suggest"
3. Add optional image URL
4. Post

## 🗄️ Database Management

### View Database
```bash
# Using DB browser (if installed)
npx drizzle-kit studio

# Or use any SQLite browser
# Database file: ./local.db
```

### Reset Database
```bash
# Remove database
rm local.db

# Recreate and reseed
npm run db:push
npm run db:seed
```

### Custom Seed Data
Edit seed files in `src/db/seeds/`:
- `profiles.ts` - User profiles
- `achievements.ts` - Achievements
- `posts.ts` - Posts
- `comments.ts` - Comments
- `postLikes.ts` - Likes

## 🎨 Customization

### Change Theme Colors
Edit `src/app/globals.css`:

```css
:root {
  --primary: oklch(0.205 0 0);
  --secondary: oklch(0.97 0 0);
  /* ... other colors */
}

.dark {
  --primary: oklch(0.922 0 0);
  /* ... dark mode colors */
}
```

### Add New Achievement Types
Edit `src/components/profile/AchievementsSection.tsx`:

```typescript
const achievementTypeConfig = {
  technical: { icon: Zap, label: "Technical", color: "bg-blue-500" },
  academic: { icon: Award, label: "Academic", color: "bg-green-500" },
  // Add more types
  volunteer: { icon: Heart, label: "Volunteer", color: "bg-red-500" },
};
```

## 🔧 Troubleshooting

### Issue: "GEMINI_API_KEY not configured"
**Solution**: Make sure you've added the API key to `.env.local` and restarted the dev server.

### Issue: Database errors
**Solution**: Delete `local.db` and run `npm run db:push` again.

### Issue: Port 3000 already in use
**Solution**: Either:
- Stop the other process using port 3000
- Or run on different port: `npm run dev -- -p 3001`

### Issue: Module not found errors
**Solution**: 
```bash
rm -rf node_modules package-lock.json
npm install
```

## 📦 Available Scripts

```bash
# Development
npm run dev              # Start dev server
npm run build           # Build for production
npm run start           # Start production server
npm run lint            # Run ESLint

# Database
npm run db:push         # Push schema to database
npm run db:studio       # Open Drizzle Studio
npm run db:seed         # Seed database with sample data
```

## 🚀 Production Deployment

### Deploy to Vercel

1. **Push to GitHub**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo>
git push -u origin main
```

2. **Deploy on Vercel**
- Go to [vercel.com](https://vercel.com)
- Import your GitHub repository
- Add environment variable: `GEMINI_API_KEY`
- Deploy

3. **Database in Production**
For production, consider:
- **Vercel Postgres** - Built-in PostgreSQL
- **Supabase** - PostgreSQL with auth
- **PlanetScale** - MySQL serverless
- **Neon** - Serverless PostgreSQL

Update database schema in production:
```bash
# After connecting production DB
npm run db:push
npm run db:seed
```

## 🔐 Adding Authentication (Optional)

This demo doesn't include authentication. To add it:

### Option 1: Supabase Auth
```bash
npm install @supabase/supabase-js @supabase/auth-helpers-nextjs
```

### Option 2: NextAuth.js
```bash
npm install next-auth
```

### Option 3: Clerk
```bash
npm install @clerk/nextjs
```

See authentication documentation for detailed implementation.

## 📱 Testing on Mobile

```bash
# Find your local IP
ipconfig getifaddr en0  # Mac
hostname -I             # Linux
ipconfig               # Windows

# Access from mobile device
http://YOUR_IP:3000
```

## 🎓 Sample Profiles to Explore

- **Profile 1** - Aarav Sharma (CS Student)
  - Hackathon winner, GSoC contributor
  - URL: `/profile/1`

- **Profile 4** - Ananya Reddy (IT Student)
  - ML researcher, Women in Tech founder
  - URL: `/profile/4`

- **Profile 11** - Dr. Rajesh Kumar (CS Faculty)
  - Research professor, best faculty award
  - URL: `/profile/11`

## 🆘 Need Help?

- Check the main [README.md](./README.md)
- Review API endpoints documentation
- Check component documentation in source files
- Open an issue on GitHub

---

Happy coding! 🎉
