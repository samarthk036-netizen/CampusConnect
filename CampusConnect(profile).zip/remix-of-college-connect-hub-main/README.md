# College Community Profile Platform 🎓

A comprehensive college-exclusive community platform built with Next.js, featuring student/faculty profiles, achievements showcase, and social posts feed with AI-powered content suggestions.

## 🚀 Features

### ✨ Core Features
- **Student & Faculty Profiles** - Detailed profile pages with customizable information
- **Achievements Showcase** - Display academic, technical, sports, cultural, and leadership achievements
- **Social Posts Feed** - Share updates, thoughts, and achievements with the community
- **AI Content Suggestions** - Gemini AI integration for generating post ideas, bios, and achievement descriptions
- **Responsive Design** - Fully responsive UI built with Tailwind CSS and shadcn/ui components

### 🎯 Profile Features
- Customizable cover and profile images
- User type badges (Student/Faculty)
- Department and year/designation display
- Bio, location, and website links
- Achievement categorization by type
- Interactive posts with like and comment functionality

### 🤖 AI Integration
- **Post Suggestions** - AI-generated post ideas based on user context
- **Bio Generator** - Personalized bio suggestions for profiles
- **Achievement Descriptions** - AI-assisted achievement descriptions

## 🛠️ Tech Stack

- **Frontend**: Next.js 15 (App Router), React, TypeScript
- **UI Components**: shadcn/ui, Tailwind CSS, Radix UI
- **Database**: SQLite with Drizzle ORM
- **AI**: Google Gemini API
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns
- **Notifications**: Sonner

## 📦 Quick Start

```bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env.local
# Add your GEMINI_API_KEY to .env.local

# Initialize database
npm run db:push
npm run db:seed

# Start development server
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

## 🎨 What's Included

### Components Built
- ✅ ProfileHeader - Cover image, avatar, user info, edit button
- ✅ AchievementsSection - Categorized achievements with type badges
- ✅ PostsFeed - Social posts with likes and comments
- ✅ EditProfileModal - Form with AI bio suggestions
- ✅ AddPostModal - Create posts with AI content ideas
- ✅ AddAchievementModal - Add achievements with AI descriptions

### API Endpoints
- ✅ GET/PATCH `/api/profiles/[id]` - Profile operations
- ✅ GET/POST `/api/posts` - Posts management
- ✅ GET/POST `/api/achievements` - Achievements management
- ✅ POST `/api/ai/suggest` - AI content generation

### Database
- ✅ 15 pre-seeded profiles (students & faculty)
- ✅ 35 diverse achievements
- ✅ 55 engaging posts
- ✅ 300+ comments and interactions

## 📚 Documentation

- [SETUP.md](./SETUP.md) - Detailed setup instructions
- API documentation in source files
- Component documentation in TSX files

## 🚀 Demo Profiles

Visit these profiles to see the platform in action:
- `/profile/1` - Aarav Sharma (CS Student, Hackathon Winner)
- `/profile/4` - Ananya Reddy (IT Student, ML Researcher)
- `/profile/11` - Dr. Rajesh Kumar (CS Faculty, Research Professor)

## 🔑 Environment Variables

Required:
- `GEMINI_API_KEY` - Get from [Google AI Studio](https://makersuite.google.com/app/apikey)

## 🎯 Next Steps

This is a demo showcasing profile page functionality. To make it production-ready, consider adding:

1. **Authentication** - Use Supabase Auth, NextAuth.js, or Clerk
2. **Authorization** - Protect routes and API endpoints
3. **File Upload** - Replace URL-based images with proper file upload
4. **Real-time Updates** - Add WebSocket or polling for live updates
5. **Comments System** - Complete the comments backend
6. **Search & Discovery** - Add user search and filtering

## 📄 License

MIT License - feel free to use this project as a starting point for your own college community platform!

---

Built with ❤️ using Next.js, React, and Google Gemini AI